# Third-party software

ZXing Core 3.5.3 — Copyright ZXing authors, Apache License 2.0.
Source: https://github.com/zxing/zxing/tree/zxing-3.5.3
Distributed unmodified as `zxing-core-3.5.3.jar`; the D8 build translates it into Android bytecode.
The Apache license is included in this folder and inside the APK.

The Eclipse ECJ compiler is a build-only tool, not included in the APK.
Android SDK build tools/platform are supplied separately under their respective SDK licenses.

## v0.3.0 phone/watch connection

Unmodified Google Play services Wearable 20.0.1 and its pinned runtime dependencies are included. Google Play services components use the Android Software Development Kit License: https://developer.android.com/studio/terms.html . AndroidX libraries use Apache License 2.0. Exact artifacts and upstream URLs are in evidence/runtime-dependencies.json; accompanying POM files retain upstream license declarations. No Google account, ads or analytics SDK has been added to the application.
