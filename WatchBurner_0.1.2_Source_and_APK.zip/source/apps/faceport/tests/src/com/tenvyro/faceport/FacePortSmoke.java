package com.tenvyro.faceport;

import android.app.Instrumentation;
import android.content.*;
import android.database.MatrixCursor;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** A separate, non-deliverable instrumentation APK. Protocol peer is SIMULATED. */
public class FacePortSmoke extends Instrumentation {
    private final ArrayList<String> passed=new ArrayList<>();
    @Override public void onCreate(Bundle b){super.onCreate(b);start();}
    private void require(boolean b,String m){if(!b)throw new AssertionError(m);passed.add(m);}
    @Override public void onStart(){Bundle result=new Bundle();FakeWatch peer=null;
        try{
            Context c=getTargetContext();
            startActivitySync(new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            require(new Identity(c).certificate!=null,"Android Keystore wrapping + BouncyCastle certificate creation");
            Identity a=new Identity(c),b=new Identity(c);require(Arrays.equals(a.certificate.getEncoded(),b.certificate.getEncoded()),"Identity survives reload");
            Bundle data=new Bundle();data.putString("uri","content://com.tenvyro.faceport.tests.fixture/apk");run(c,"import",data);
            require("APK ready".equals(FacePortService.state),"Valid APK import and metadata extraction");
            require(ApkStore.info(c).optString("sha256").length()==64,"APK SHA-256 calculated");
            peer=new FakeWatch();peer.start();
            Bundle conn=new Bundle();conn.putString("host","127.0.0.1");conn.putInt("port",peer.port());
            peer.isWatch=false;run(c,"connect",conn);
            require(!FacePortService.connected&&FacePortService.detail.contains("does not identify itself"),"Non-watch ADB endpoint rejected");
            peer.isWatch=true;run(c,"connect",conn);
            require(FacePortService.connected,"SIMULATED watch accepted after feature+model+SDK probe");
            run(c,"install",null);
            require("Installed".equals(FacePortService.state),"SIMULATED sync upload and pm Success accepted");
            require(ApkStore.info(c).optString("sha256").equals(peer.uploadHash),"Uploaded bytes match local SHA-256");
            require("[]".equals(c.getSharedPreferences("faceport",0).getString("pendingUploads","[]")),"Temporary upload cleanup confirmed");
            peer.reject=true;run(c,"install",null);
            require("Needs attention".equals(FacePortService.state)&&FacePortService.detail.contains("different signing key"),"SIMULATED pm signature rejection never shown as success");
            run(c,"disconnect",null);require(!FacePortService.connected,"Disconnect clears eligibility");
            result.putString("status","PASS — SIMULATED protocol peer; physical Galaxy Watch untested");result.putString("checks",passed.toString());finish(-1,result);
        }catch(Throwable e){result.putString("status","FAIL");result.putString("checks",passed.toString());result.putString("error",android.util.Log.getStackTraceString(e));finish(0,result);}
        finally{if(peer!=null)peer.close();}
    }
    private void run(Context c,String action,Bundle b)throws Exception {
        FacePortService.start(c,action,b);long deadline=SystemClock.elapsedRealtime()+90000;boolean started=false;
        while(SystemClock.elapsedRealtime()<deadline){SystemClock.sleep(50);if(FacePortService.busy)started=true;if(started&&!FacePortService.busy)return;
            if(!FacePortService.busy&&SystemClock.elapsedRealtime()>deadline-88500)return;}
        throw new IOException("Timed out waiting for "+action+"; "+FacePortService.state+": "+FacePortService.detail);
    }
    public static final class Fixture extends ContentProvider{
        public boolean onCreate(){return true;}
        public String getType(Uri u){return "application/vnd.android.package-archive";}
        public Cursor query(Uri u,String[] p,String s,String[] a,String o){MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});File f=new File(getContext().getApplicationInfo().sourceDir);c.addRow(new Object[]{"fixture.apk",f.length()});return c;}
        public ParcelFileDescriptor openFile(Uri u,String m)throws FileNotFoundException{return ParcelFileDescriptor.open(new File(getContext().getApplicationInfo().sourceDir),ParcelFileDescriptor.MODE_READ_ONLY);}
        public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}public int update(Uri u,ContentValues v,String s,String[] a){return 0;}public int delete(Uri u,String s,String[] a){return 0;}
    }
    static final class FakeWatch implements AutoCloseable {
        final ServerSocket listener;volatile boolean isWatch=true,reject=false,closed=false;volatile String uploadHash="";
        FakeWatch()throws IOException{listener=new ServerSocket(0,8,InetAddress.getByName("127.0.0.1"));}
        int port(){return listener.getLocalPort();}
        void start(){new Thread(()->{while(!closed)try{Socket s=listener.accept();new Thread(()->serve(s)).start();}catch(Exception ignored){}},"SIMULATED-watch").start();}
        public void close(){closed=true;try{listener.close();}catch(Exception ignored){}}
        void serve(Socket socket){try(Socket s=socket){InputStream in=s.getInputStream();OutputStream out=s.getOutputStream();Map<Integer,String> kind=new HashMap<>();Map<Integer,ByteArrayOutputStream> sync=new HashMap<>();Map<Integer,ByteArrayOutputStream> uploads=new HashMap<>();int remote=70;
            while(!closed){byte[] h=new byte[24];AdbClient.readFully(in,h);int cmd=AdbClient.littleInt(h,0),local=AdbClient.littleInt(h,4),rid=AdbClient.littleInt(h,8),length=AdbClient.littleInt(h,12);if(length<0||length>1<<20)throw new IOException();byte[] bytes=new byte[length];AdbClient.readFully(in,bytes);
                String tag=tag(cmd);
                if(tag.equals("CNXN")){send(out,"CNXN",0x01000001,4096,"device::features=\0".getBytes(StandardCharsets.UTF_8));}
                else if(tag.equals("OPEN")){String destination=new String(bytes,StandardCharsets.UTF_8).replace("\0","");rid=++remote;kind.put(rid,destination);send(out,"OKAY",rid,local,new byte[0]);
                    if(destination.equals("sync:")){sync.put(rid,new ByteArrayOutputStream());uploads.put(rid,new ByteArrayOutputStream());}
                    else{String answer;if(destination.contains("getprop ro.product.model"))answer="SIMULATED Watch\n35\nSIMULATED-SERIAL\n"+(isWatch?"feature:android.hardware.type.watch\n":"")+"FACEPORT_PROBE_DONE\n";
                        else if(destination.contains("pm install"))answer=reject?"Failure [INSTALL_FAILED_UPDATE_INCOMPATIBLE]\nFACEPORT_INSTALL_RC:1\n":"Success\nFACEPORT_INSTALL_RC:0\n";
                        else if(destination.contains("rm -f"))answer="FACEPORT_CLEAN_RC:0\n";else answer="unsupported\n";
                        send(out,"WRTE",rid,local,answer.getBytes(StandardCharsets.UTF_8));}
                }else if(tag.equals("WRTE")){send(out,"OKAY",rid,local,new byte[0]);ByteArrayOutputStream buffer=sync.get(rid);if(buffer==null)continue;buffer.write(bytes);
                    byte[] data=buffer.toByteArray();int used=0;while(data.length-used>=8){String id=new String(data,used,4,StandardCharsets.US_ASCII);int n=AdbClient.littleInt(data,used+4);
                        if(id.equals("DONE")){uploadHash=ApkStore.hex(MessageDigest.getInstance("SHA-256").digest(uploads.get(rid).toByteArray()));send(out,"WRTE",rid,local,new byte[]{'O','K','A','Y',0,0,0,0});used+=8;break;}
                        if(n<0||n>1048576)throw new IOException("Bad sync length");if(data.length-used-8<n)break;if(id.equals("DATA"))uploads.get(rid).write(data,used+8,n);used+=8+n;}
                    buffer.reset();buffer.write(data,used,data.length-used);
                }else if(tag.equals("OKAY")){String destination=kind.get(rid);if(destination!=null&&!destination.equals("sync:")){send(out,"CLSE",rid,local,new byte[0]);kind.remove(rid);}}
                else if(tag.equals("CLSE")){send(out,"CLSE",rid,local,new byte[0]);kind.remove(rid);}
            }
        }catch(Exception ignored){}}
        static String tag(int n){byte[] b=new byte[4];for(int i=0;i<4;i++)b[i]=(byte)(n>>>(8*i));return new String(b,StandardCharsets.US_ASCII);}
        static void send(OutputStream out,String tag,int a,int b,byte[] payload)throws IOException{ByteArrayOutputStream packet=new ByteArrayOutputStream();int cmd=0;for(int i=0;i<4;i++)cmd|=(tag.charAt(i)&255)<<(i*8);int checksum=0;for(byte v:payload)checksum+=v&255;for(int n:new int[]{cmd,a,b,payload.length,checksum,cmd^0xffffffff})for(int i=0;i<4;i++)packet.write((n>>>(i*8))&255);packet.write(payload);out.write(packet.toByteArray());out.flush();}
    }
}
