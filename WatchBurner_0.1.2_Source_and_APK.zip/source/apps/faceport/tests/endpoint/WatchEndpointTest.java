package com.tenvyro.faceport;

public final class WatchEndpointTest {
    private static int checks;

    public static void main(String[] args) {
        valid("192.168.1.24", "37001", "192.168.1.24", 37001);
        valid("192.168.1.24:37001", "", "192.168.1.24", 37001);
        valid("192.168.1.24:37001", null, "192.168.1.24", 37001);
        valid("192.168.1.24:37001", "37001", "192.168.1.24", 37001);
        valid("  10.0.0.8:42000\n", "\t42000 ", "10.0.0.8", 42000);
        valid("172.16.0.9", " 65535 ", "172.16.0.9", 65535);
        valid("1.2.3.4", "1", "1.2.3.4", 1);
        valid("10.0.0.8:00080", "80", "10.0.0.8", 80);
        invalid("192.168.1.24:37001", "42000", "do not match");
        invalid("", "37001", "IP address");
        invalid(null, "37001", "IP address");
        invalid("192.168.1.24", "", "Enter the port");
        invalid("192.168.1.24", null, "Enter the port");
        invalid("192.168.1.24:", "37001", "port number");
        invalid("192.168.1.24:0", "", "port number");
        invalid("192.168.1.24", "0", "port number");
        invalid("192.168.1.24", "65536", "port number");
        invalid("192.168.1.24", "999999999999999999", "port number");
        invalid("192.168.1.24", "-1", "port number");
        invalid("192.168.1.24", "+80", "port number");
        invalid("192.168.1.24", "37 001", "port number");
        invalid("192.168.1.24", "１２３４５", "port number");
        invalid("http://192.168.1.24:37001", "", "without a web address");
        invalid("192.168.1.24/path", "37001", "without a web address");
        invalid("192.168.1.24?port=37001", "37001", "without a web address");
        invalid("192.168.1.24#watch", "37001", "without a web address");
        invalid("watch.local", "37001", "IPv4 address");
        invalid("[fe80::1234]:37001", "", "IPv6");
        invalid("fe80::1234", "37001", "IPv6");
        invalid("192.168.1.24:37001:42000", "", "IPv6");
        invalid("192.168.001.24", "37001", "leading zeros");
        invalid("192.168.1.256", "37001", "IPv4 address");
        invalid("192.168.1", "37001", "IPv4 address");
        invalid("192.168.1.24.5", "37001", "IPv4 address");
        invalid("192..1.24", "37001", "IPv4 address");
        invalid("192.168.1.24.", "37001", "IPv4 address");
        invalid("192.168.1.-1", "37001", "IPv4 address");
        invalid("192.168.1. 24", "37001", "IPv4 address");
        invalid("１９２.168.1.24", "37001", "IPv4 address");
        invalid("192.168.1.999999999999", "37001", "IPv4 address");
        invalid("192.168.1.24: 37001", "", "port number");
        pairing("123456", "123456");
        pairing(" 001234\r\n", "001234");
        pairing("\t000000 ", "000000");
        pairing("\u2003123456\u2003", "123456");
        badPairing(null);
        badPairing("");
        badPairing("12345");
        badPairing("1234567");
        badPairing("123 456");
        badPairing("12\n3456");
        badPairing("１２３４５６");
        badPairing("+12345");
        badPairing("abcdef");
        badPairing("\u0000123456");
        System.out.println("PASS " + checks + " endpoint and pairing-input checks");
    }

    private static void valid(String host, String port, String wantedHost, int wantedPort) {
        WatchEndpoint value = WatchEndpoint.parse(host, port);
        if (!wantedHost.equals(value.host) || wantedPort != value.port) {
            throw new AssertionError("Accepted endpoint was changed unexpectedly");
        }
        checks++;
    }

    private static void invalid(String host, String port, String messagePart) {
        try {
            WatchEndpoint.parse(host, port);
            throw new AssertionError("Invalid endpoint was accepted");
        } catch (IllegalArgumentException expected) {
            if (!expected.getMessage().contains(messagePart)) {
                throw new AssertionError("Expected a helpful explanation: " + messagePart);
            }
            checks++;
        }
    }

    private static void pairing(String input, String wanted) {
        if (!wanted.equals(WatchEndpoint.parsePairingCode(input))) {
            throw new AssertionError("Pairing input was changed unexpectedly");
        }
        checks++;
    }

    private static void badPairing(String input) {
        try {
            WatchEndpoint.parsePairingCode(input);
            throw new AssertionError("Invalid pairing input was accepted");
        } catch (IllegalArgumentException expected) {
            if (!expected.getMessage().equals("Enter the current six-digit pairing code from your watch, with no spaces between digits.")) {
                throw new AssertionError("Pairing error must be helpful and never contain the user's code");
            }
            checks++;
        }
    }
}
