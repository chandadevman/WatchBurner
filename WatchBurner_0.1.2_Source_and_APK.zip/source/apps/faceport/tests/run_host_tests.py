#!/usr/bin/env python3
"""Compile production Java + test harness against the official SDK stubs; exercise a simulated ADB TCP peer."""
from pathlib import Path
import subprocess,os,json,time,zipfile
root=Path(__file__).resolve().parents[3]
app=root/'apps/faceport'
build=app/'tests/host-build';build.mkdir(exist_ok=True)
android=root/'toolchain/sdk-platform/android-35/android.jar'
libs=list((app/'third_party').glob('*.jar'))
libs=[p for p in libs if not p.name.endswith('-sources.jar')]
for name in ('spake2-android-2.2.1','conscrypt-android-2.5.3'):
    target=build/(name+'-classes.jar')
    with zipfile.ZipFile(app/'third_party'/(name+'.aar')) as archive:
        target.write_bytes(archive.read('classes.jar'))
    libs.append(target)
sources=list((app/'src/main/java').rglob('*.java'))+list((app/'vendor/libadb').rglob('*.java'))+list((app/'tests/src').rglob('*.java'))+list((app/'tests/host').rglob('*.java'))
config=json.loads((root/'build-config/faceport.json').read_text())
generated=root/config['work_dir']/'generated'
if not generated.is_dir():
    raise SystemExit('Build first: python3 toolchain/build_apk.py build-config/faceport.json')
sources+=list(generated.rglob('*.java'))
cp=os.pathsep.join(map(str,[android]+libs))
cmd=['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(build)]+list(map(str,sources))
r=subprocess.run(cmd,text=True,capture_output=True);(build/'compile.log').write_text(r.stdout+r.stderr)
if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
start=time.monotonic()
r=subprocess.run(['java','-cp',str(build)+os.pathsep+cp,'com.tenvyro.faceport.HostProtocolTest'],text=True,capture_output=True,timeout=90)
output=r.stdout+r.stderr;(build/'results.txt').write_text(output)
result={'status':'PASS' if r.returncode==0 else 'FAIL','scope':'SIMULATED TCP ADB peer using production protocol implementation','seconds':round(time.monotonic()-start,3),'checks':r.stdout.count('PASS '),'not_proven':['TLS/SPAKE pairing','Android lifecycle/UI','physical Galaxy Watch install'],'output':output}
(app/'tests/host-test-results.json').write_text(json.dumps(result,indent=2)+'\n');print(output);raise SystemExit(r.returncode)
