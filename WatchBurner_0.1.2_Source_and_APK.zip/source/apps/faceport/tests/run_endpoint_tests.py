#!/usr/bin/env python3
"""Exercise the production input parser directly with Java, without Android mocks."""
from pathlib import Path
import json
import re
import subprocess
import tempfile

tests = Path(__file__).resolve().parent
app = tests.parent
sources = [
    app / "src/main/java/com/tenvyro/faceport/WatchEndpoint.java",
    tests / "endpoint/WatchEndpointTest.java",
]
with tempfile.TemporaryDirectory(prefix="watchburner-endpoint-") as classes:
    subprocess.run([
        "java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-source", "8",
        "-target", "8", "-encoding", "UTF-8", "-d", classes,
        *map(str, sources),
    ], check=True, capture_output=True, text=True)
    result = subprocess.run([
        "java", "-cp", classes, "com.tenvyro.faceport.WatchEndpointTest",
    ], capture_output=True, text=True, timeout=15)

match = re.search(r"PASS (\d+) endpoint", result.stdout)
report = {
    "status": "PASS" if result.returncode == 0 and match else "FAIL",
    "scope": "REAL host execution of production pure-Java input parser with synthetic inputs",
    "checks": int(match.group(1)) if match else 0,
    "not_proven": ["Android UI field integration", "Watch pairing", "Network connectivity"],
    "output": result.stdout + result.stderr,
}
(tests / "endpoint-test-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(report["output"], end="")
raise SystemExit(0 if report["status"] == "PASS" else 1)
