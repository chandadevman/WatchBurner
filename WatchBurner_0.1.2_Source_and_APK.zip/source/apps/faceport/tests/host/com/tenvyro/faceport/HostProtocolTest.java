package com.tenvyro.faceport;
import io.github.muntashirakon.adb.*;
import java.io.*;
import java.security.*;
import java.security.cert.Certificate;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Runs the production ADB transport against an explicitly simulated TCP peer. No TLS/device claim. */
public final class HostProtocolTest {
    static final class Client extends AbsAdbConnectionManager {
        final KeyPair pair;
        Client()throws Exception{KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(2048);pair=g.generateKeyPair();setApi(35);setTimeout(5,TimeUnit.SECONDS);}
        protected PrivateKey getPrivateKey(){return pair.getPrivate();}
        protected Certificate getCertificate(){return new Certificate("X.509"){
            public byte[] getEncoded(){return new byte[0];}public void verify(PublicKey key){}public void verify(PublicKey key,String provider){}public String toString(){return "SIMULATED test certificate";}public PublicKey getPublicKey(){return pair.getPublic();}};}
        protected String getDeviceName(){return "HostProtocolTest";}
        String read(String command)throws Exception{try(AdbStream s=openStream("shell:"+command);InputStream in=s.openInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[7];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
    }
    static void check(boolean value,String label){if(!value)throw new AssertionError(label);System.out.println("PASS "+label);}
    public static void main(String[] args)throws Exception{
        FacePortSmoke.FakeWatch peer=new FacePortSmoke.FakeWatch();peer.start();Client client=new Client();
        try{
            check(client.connect("127.0.0.1",peer.port()),"production library TCP ADB handshake");
            String probe=client.read("getprop ro.product.model");check(probe.contains("feature:android.hardware.type.watch")&&probe.endsWith("FACEPORT_PROBE_DONE\n"),"fragmented shell response drains before remote EOF");
            check(WatchProbe.parse(probe).sdk==35,"production eligibility parser accepts complete watch probe");
            try{WatchProbe.parse(probe.replace("feature:android.hardware.type.watch\n",""));throw new AssertionError("Non-watch passed");}catch(IOException expected){check(expected.getMessage().contains("does not identify itself"),"production eligibility parser rejects non-watch target");}
            try{WatchProbe.parse(probe.replace("FACEPORT_PROBE_DONE", "partial"));throw new AssertionError("Incomplete probe passed");}catch(IOException expected){check(true,"production eligibility parser rejects incomplete response");}
            File data=File.createTempFile("faceport-protocol-",".apk");byte[] random=new byte[512*1024+37];new Random(219L).nextBytes(random);try(FileOutputStream out=new FileOutputStream(data)){out.write(random);}
            long[] bytes={0};AdbClient.pushStream(client.openStream("sync:"),data,"/data/local/tmp/faceport-00000000-0000-0000-0000-000000000000.apk",new AdbClient.Progress(){public void check(){}public void update(long sent,long total){bytes[0]=sent;}});
            check(bytes[0]==random.length,"production sync transfer progress reaches full file length");
            check(peer.uploadHash.equals(ApkStore.hex(MessageDigest.getInstance("SHA-256").digest(random))),"production sync SEND/DATA/DONE transfers byte-exact payload");
            check(client.read("pm install -r fixture").matches("(?s).*\\bSuccess\\s*\nFACEPORT_INSTALL_RC:0\\s*$"),"simulated pm Success plus zero return accepted");
            peer.reject=true;String rejection=client.read("pm install -r fixture");check(!rejection.matches("(?s).*\\bSuccess\\s*\nFACEPORT_INSTALL_RC:0\\s*$"),"simulated pm failure does not match successful result");
            check(FacePortService.friendlyInstallError(rejection).contains("different signing key"),"production failure mapper explains signature mismatch");
            check(client.read("rm -f fixture").endsWith("FACEPORT_CLEAN_RC:0\n"),"simulated temporary-file cleanup returns confirmation");
            try{AdbClient.pushStream(client.openStream("sync:"),data,"/data/local/tmp/faceport-00000000-0000-0000-0000-000000000000.apk",new AdbClient.Progress(){public void check()throws IOException{throw new IOException("SIMULATED cancellation");}public void update(long a,long b){}});throw new AssertionError("cancel not observed");}
            catch(IOException expected){check(expected.getMessage().contains("SIMULATED cancellation"),"production transfer honours cancellation before DATA");}
            data.delete();
            System.out.println("RESULT PASS: 12 checks; SIMULATED ADB peer. TLS pairing, Android lifecycle and physical watch remain NOT PROVEN.");
        }finally{client.disconnect();peer.close();}
    }
}
