# ReapTyc WatchBurner — beta 0.1.2

Watch Apps & Faces Installer. Built by Tenvyro.

Native Android phone application for selecting a standalone Wear OS APK and sending it to a user-authorized watch over Android's wireless debugging connection. It can carry both watch-face APKs and ordinary Wear OS app APKs. No watch-side WatchBurner installation or Termux is required.

## Status and evidence

- **REAL / IMPLEMENTED:** Android Java application, storage-access-framework file selection, bounded file copy, package/version/minimum-SDK/permissions inspection, file and signer SHA-256, encrypted persistent ADB identity, six-digit TLS/SPAKE pairing, explicit IPv4 connection, model/API/watch-feature probe, streamed ADB sync transfer, `pm install -r`, actual command-result interpretation, install history, cancellation, foreground progress and temporary-file recovery.
- **REAL / BUILD VERIFIED:** Official Android API 35 compilation; APK signing and ZIP alignment. The exact Conscrypt and SPAKE2 arm64 native binaries have 16 KB ELF LOAD alignment. Build details are in the generated APK build receipt.
- **REAL / HOST EXECUTION:** 55 checks passed against the production endpoint/pairing-input parser with synthetic inputs. This verifies parser behavior, not Android field rendering or connectivity.
- **SIMULATED:** `tests/run_host_tests.py` executes the production transport and binary upload against a deliberately simulated TCP ADB peer. It is not a physical watch or TLS-pairing test. See `tests/host-test-results.json` for the actual execution result; do not count the test unless its status is PASS.
- **NOT PROVEN:** Physical Galaxy Watch pairing/install, phone UI/lifecycle behavior, live Android Keystore/Conscrypt/SPAKE initialization, battery use, 16 KB device runtime, and every watch-face format. A separate signed instrumentation suite is provided but is not counted as passed unless it actually runs.
- **PLANNED:** IPv6/mDNS discovery, multiple APK split sets, queued installs, store delivery, automatic WFF suitability checks, and fuller device compatibility coverage.

This is an engineering beta, not a claim of 98% finished or production certification. A successful `pm install` proves package acceptance by the connected watch; it does not prove that the face appears in the face picker or renders on that OS version.

## Install and use

1. Install `ReapTyc_WatchBurner_0.1.2_beta.apk` on the Android phone. Minimum Android 8/API 26; target API 35. This can be a fresh installation: no FacePort or watch-side WatchBurner app is required. Open the app and tap **Set up my watch**.
2. Keep the phone and watch on the same trusted Wi-Fi. Charge the watch for larger transfers.
3. On Galaxy Watch 6, open **Settings → About watch → Software information** and tap **Software version** five times. In **Developer options**, enable **ADB debugging** and **Wireless debugging**. Menu names may vary with updates.
4. Open **Pair new device** on the watch. In WatchBurner → **Connect**, enter **Watch IP address**, **Pairing port** and **Six-digit pairing code**. Tap **Pair with watch**. Keep the current code visible on the watch. The code is not persisted or logged in history.
5. Return to the main **Wireless debugging** screen on the watch. Its **connection port is usually different**. Enter **Connection port** in WatchBurner and tap **Connect watch**. If already paired, use **Already paired? Show connection**. You can paste **IP:port** into the IP field if the separate port is empty; conflicting ports produce a validation message.
6. After checking the connected watch model, tap **Choose an APK**. In **Install**, tap **Choose APK**, select the watch APK and optionally **Review file details**. Tap **Install on watch**, then confirm **Send & install**.
7. After **Installed**, open an ordinary app from the watch app list, or select a face in the watch face picker. **Check your watch** means the install outcome is unknown, so verify it before retrying. Turn Wireless debugging off when finished.

Progress notifications are optional. Use **Enable progress notifications** on the welcome screen or in **Help** to request them. The app remains usable without notification permission.

## 0.1.2 polish

- ReapTyc blue/gold styling, updated watch-and-transfer icon, and a phone-first welcome with **Set up my watch**.
- Explicit **A · Pair once** and **B · Connect each session** sections, inline input validation, and plain explanations for unavailable install actions.
- IP/port drafts survive tab changes and recreation. Pairing codes stay out of preferences and saved view state, and clear on submission or when the app stops.
- Progress-only updates change the existing status views. Full layout refreshes are reserved for control/state changes and preserve draft text and per-tab scroll positions.
- Flexible control heights, two-column navigation on narrow or large-text layouts, labels associated with inputs, selected tab states, and meaningful status announcements.
- Foreground progress is an optional permission request with an explanation; it no longer interrupts every operation automatically.

These are source changes, not proof of rendered usability. Real phone launch, keyboard behavior, TalkBack, and watch pairing remain **NOT PROVEN**. The release note is `docs/WATCHBURNER_POLISH.md` in the handoff.

No account, backend, subscription, cloud upload, unknown-sources permission or broad storage access is used. The selected APK remains in WatchBurner's private local storage until replaced or removed. The last 40 install attempts stay on the phone until cleared. Diagnostic sharing requires the user's explicit Android share-sheet action.

## Behavior and limits

- Accepts one standalone `.apk` at a time, up to 512 MiB. Rejects ZIP/APKS/XAPK/AAB bundles and readable split APKs. An incomplete base APK can still be rejected by the watch with `INSTALL_FAILED_MISSING_SPLIT`.
- The connected target must report a model, numeric Android API and `android.hardware.type.watch` feature before the install action is eligible. There is no shipping test bypass or general ADB terminal.
- Watch minimum-SDK mismatch is blocked before transfer. Missing watch declaration in the selected APK is flagged for review because some APKs omit it.
- Uses normal update mode `pm install -r`. No root, forced downgrade, signature bypass, silent uninstall, or permission auto-grant is attempted. An update must have the compatible original signing key.
- Cancelling after installation was submitted may not stop Android's package commit. Missing final output is recorded as **UNKNOWN**, never as successful or rolled back. Check the watch before retrying.
- Each upload has a generated temporary filename. The exact path is journaled before transfer. Cleanup is confirmed via the remote shell's return code; leftover paths are retried only when the same watch serial reconnects. No wildcard deletion occurs. If an OS does not expose a serial, cross-session automatic cleanup cannot safely identify that watch; manual maintenance remains necessary.
- UI state handles background transfer through a data-sync foreground service and partial wake lock with time bounds. No persistent process-survival or uninterrupted-transfer guarantee is claimed.
- IPv4 addresses only in this beta. Local network client isolation, changing ports, sleeping watch Wi-Fi, lost network, unsupported APK architecture and insufficient watch storage have to be resolved on-device.
- Watch faces still depend on supported platform format. New Wear OS policies and Watch Face Format requirements mean legacy engine APKs may install without becoming usable faces.
- Android 17 local-network permission behavior, Play publishing approval and store policy review are outside this beta gate.

## Build, replace libraries, and handoff

The workspace-level `toolchain/build_apk.py` uses official Android build tools. The config lists exact dependency hashes, local sources, resources and assets. Private signing material is referenced, never included in this app directory.

```bash
python toolchain/build_apk.py build-config/faceport.json
python apps/faceport/tests/run_endpoint_tests.py
python apps/faceport/tests/run_host_tests.py
python toolchain/build_apk.py apps/faceport/tests/build.json
```

Use your own signing keystore and password-file path in `build.json` when rebuilding outside the supplied workspace. Reusing the original release key is required to update the same installed package without uninstalling it.

The instrumentation APK is a developer test artifact, not a customer companion. With a booted, authorized Android test device:

```bash
adb install -r dist/ReapTyc_WatchBurner_0.1.2_beta.apk
adb install -r -t toolchain/test-artifacts/FacePort_protocol_tests.apk
adb shell am instrument -w com.tenvyro.faceport.tests/com.tenvyro.faceport.FacePortSmoke
adb uninstall com.tenvyro.faceport.tests
```

The instrumented peer is deliberately simulated and has no shipped bypass. The suite exercises Android identity storage, APK metadata, watch/non-watch gating, byte-exact upload, positive/negative installer results and cleanup when executed. It must be run on an isolated test profile: it replaces WatchBurner's selected file and test history.

### Dependency provenance and local patches

`third_party` contains pinned AAR/JAR files, their original source snapshots, relevant upstream native source and full license texts. `vendor/libadb` is the exact 3.1.1 source plus:

1. Finite socket-connect and pairing read deadlines.
2. A condition-based ADB OPEN wait with a 15-second bound, addressing a lost notification race.
3. Draining queued and buffered payload before remote EOF, with shared locking to avoid a close/read race.
4. Closing pairing sockets on failed handshake and null-safe partial cleanup.

These changes are recorded as a unified diff in `vendor/libadb-faceport.patch`. The upstream library states it has not undergone a security audit; no audit is claimed here. WatchBurner intentionally exposes only the narrow pairing/probe/transfer/install/temporary-cleanup flow.

SPAKE2's LGPL component can be modified and relinked. Unminified application source, native submodule snapshot, dependency binaries and rebuild instructions are included. Replace the corresponding dependency AAR, update its expected digest and rebuild. For native source, extract `spake2-2.2.1-source.zip`, place the contents of `spake2-c-0d15933-source.zip` inside `android/src/main/cpp/spake2-c`, and use its supplied Gradle/CMake build instructions. No additional restriction on reverse engineering for debugging LGPL component modifications is imposed. Keep these notices with redistributed builds.

### Rollback

WatchBurner is the renamed FacePort product and updates its existing `com.tenvyro.faceport` package with the same signing key. Local settings, APK selection, history, encrypted identity and pending-upload journal keep their original storage keys. Physical in-place update remains untested. To remove the beta, uninstall WatchBurner from the phone, and forget **ReapTyc WatchBurner** (or the earlier **FacePort** label) in the watch's Wireless debugging paired-device list. Apps previously installed on the watch remain installed. Remove them separately from the watch only if desired; removing an app may delete its data. Rollback to an older WatchBurner binary may require uninstalling the newer app because ordinary version downgrades are not forced.

## Physical-device acceptance gates

1. Fresh install/open on Galaxy A56 and a second supported Android phone.
2. Fresh pairing to Galaxy Watch 6; wrong/expired code; changed port; no-network recovery.
3. Identity persistence after process death, phone reboot and app update.
4. A small valid Wear OS app install and update with matching signer; verification from the watch app list.
5. Valid watch-face install followed by explicit appearance/render confirmation in the face picker.
6. Wrong signer, older version, unsupported ABI, insufficient storage, corrupt APK and non-watch target produce no false success.
7. Cancel copy, cancel transfer, network loss, background/resume and install-stage cancellation preserve truthful status; exact temporary uploads are removed after reconnect.
8. TalkBack, large font, landscape, keyboard/insets and narrow phone layouts are reviewed on real UI.
9. Measure elapsed install time and battery effect. No performance number is asserted without this measurement.

## Primary references

- Android Wear OS Wi-Fi debugging: https://developer.android.com/training/wearables/get-started/debug-wifi
- Android ADB command and wireless pairing documentation: https://developer.android.com/tools/adb
- Wear OS hardware debugging: https://developer.android.com/training/wearables/get-started/debugging
- LibADB source and licensing: https://github.com/MuntashirAkon/libadb-android/tree/3.1.1
- SPAKE2 Android source: https://github.com/MuntashirAkon/spake2-java/tree/2.2.1
- Native SPAKE2 snapshot: https://github.com/MuntashirAkon/spake2-c/tree/0d15933e5ba3e662cb01245a7ac0dc9fca3eac31
- Conscrypt source: https://github.com/google/conscrypt/tree/2.5.3
- Bouncy Castle source: https://github.com/bcgit/bc-java/tree/r1rv81

Research checked 2026-10-10 UTC. Hardware capabilities and current publishing rules need verification against the actual target at release time.
