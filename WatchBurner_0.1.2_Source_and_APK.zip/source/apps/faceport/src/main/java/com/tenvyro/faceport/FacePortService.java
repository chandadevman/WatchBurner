package com.tenvyro.faceport;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class FacePortService extends Service {
    static final String UPDATE="com.tenvyro.faceport.UPDATE";
    static volatile boolean busy=false,connected=false;
    static volatile int progress=-1,watchSdk=0;
    static volatile String state="Ready",detail="Choose an APK, then connect your watch.",device="No watch connected";
    private static volatile FacePortService current;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService watchdog=Executors.newSingleThreadScheduledExecutor();
    private volatile AdbClient client;
    private volatile boolean cancelled,timedOut,installSubmitted;
    private volatile Thread workThread;
    private PowerManager.WakeLock wakeLock;
    private long lastProgress;
    private String targetId="",targetHost="";
    static void start(Context c,String action,Bundle extras) {
        Intent i=new Intent(c,FacePortService.class).setAction(action);if(extras!=null)i.putExtras(extras);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);
    }
    @Override public void onCreate() {
        super.onCreate(); current=this;
        if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel("operation","Watch transfers",NotificationManager.IMPORTANCE_LOW));
        wakeLock=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"WatchBurner:operation");
    }
    private Notification notification() {
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent cancel=PendingIntent.getService(this,1,new Intent(this,FacePortService.class).setAction("cancel"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"operation"):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_sys_upload).setContentTitle("WatchBurner · "+state).setContentText(detail)
                .setContentIntent(open).setOngoing(busy).setOnlyAlertOnce(true);
        if(busy)b.addAction(android.R.drawable.ic_menu_close_clear_cancel,"Cancel",cancel);
        if(progress>=0)b.setProgress(100,progress,false);return b.build();
    }
    private void publish(String title,String message,int percent) {
        state=title;detail=message;progress=percent;
        sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
        if(busy)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(29,notification());
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        startForeground(29,notification());
        String action=intent==null?"":intent.getAction();
        if("cancel".equals(action)) { cancel(false); if(!busy)stopForeground(true); return START_NOT_STICKY; }
        if(busy)return START_NOT_STICKY;
        busy=true;cancelled=false;timedOut=false;installSubmitted=false;lastProgress=0;
        publish("Working","Preparing…",-1);wakeLock.acquire(11*60*1000L);
        final Bundle args=intent==null?new Bundle():intent.getExtras()==null?new Bundle():intent.getExtras();
        worker.execute(()->{
            workThread=Thread.currentThread();
            ScheduledFuture<?> timeout=watchdog.schedule(()->cancel(true),"install".equals(action)?600:90,TimeUnit.SECONDS);
            try {
                if("import".equals(action))importFile(args);
                else if("pair".equals(action))pair(args);
                else if("connect".equals(action))connect(args);
                else if("install".equals(action))install();
                else if("disconnect".equals(action))disconnect();
                else throw new IOException("Unknown action");
            } catch(Throwable e) {
                String message=error(e);
                if(installSubmitted)message="Install result is unknown. Check the watch before retrying. "+message;
                publish(installSubmitted?"Check your watch":cancelled?"Cancelled":"Needs attention",message,-1);
                if("install".equals(action))history(installSubmitted?"UNKNOWN":cancelled?"CANCELLED":"FAILED",message);
                if(client!=null)connected=connected&&client.isConnected();
            } finally {
                timeout.cancel(false);workThread=null;busy=false;
                Thread.interrupted();if(wakeLock.isHeld())wakeLock.release();stopForeground(true);
                sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
            }
        });
        return START_NOT_STICKY;
    }
    private AdbClient adb() throws Exception { if(client==null)client=new AdbClient(this);return client; }
    private void check() throws IOException { if(cancelled||Thread.currentThread().isInterrupted())throw new IOException(timedOut?"The operation timed out. Check Wi-Fi and the current watch port.":"Cancelled by you"); }
    private AdbClient.Progress meter(String title) { return new AdbClient.Progress(){
        public void check()throws IOException{FacePortService.this.check();}
        public void update(long sent,long total){long now=SystemClock.elapsedRealtime();if(now-lastProgress>200||sent==total){lastProgress=now;publish(title,total>0?String.format(Locale.US,"%.1f / %.1f MB",sent/1048576d,total/1048576d):String.format(Locale.US,"%.1f MB copied",sent/1048576d),total>0?(int)(sent*100/total):-1);}}
    }; }
    private void importFile(Bundle args)throws Exception {
        publish("Reading APK","Checking the file on your phone…",-1);
        JSONObject apk=ApkStore.importApk(this,Uri.parse(args.getString("uri","")),meter("Reading APK"));check();
        publish("APK ready",apk.optString("label")+" is ready for review. Nothing has been installed.",-1);
    }
    private static String host(Bundle args)throws IOException {
        String host=args.getString("host","").trim();
        String[] parts=host.split("\\.",-1);if(parts.length!=4)throw new IOException("Enter the watch IP address as four numbers, such as 192.168.1.25");
        for(String part:parts)try{if(!part.matches("[0-9]{1,3}")||Integer.parseInt(part)>255)throw new Exception();}catch(Exception e){throw new IOException("That watch IP address is not valid");}
        return host;
    }
    private static int port(Bundle args)throws IOException {int p=args.getInt("port",0);if(p<1||p>65535)throw new IOException("Enter the port shown on your watch (1–65535)");return p;}
    private void pair(Bundle args)throws Exception {
        String host=host(args);int port=port(args);String code=args.getString("code","").trim();
        if(!code.matches("[0-9]{6}"))throw new IOException("Enter the six-digit pairing code currently shown on your watch");
        publish("Pairing","Keep the watch’s pairing-code screen open…",-1);AdbClient c=adb();
        if(c.isConnected())c.disconnect();connected=false;check();
        if(!c.pair(host,port,code))throw new IOException("Pairing was not accepted. Open a new pairing code and retry.");
        check();saveHost(host);publish("Paired","Now use the connection port from the main Wireless debugging screen, then tap Connect.",-1);
    }
    private void connect(Bundle args)throws Exception {
        String host=host(args);int port=port(args);AdbClient c=adb();if(c.isConnected())c.disconnect();
        connected=false;publish("Connecting","Checking the device at "+host+":"+port+"…",-1);check();
        if(!c.connect(host,port))throw new IOException("The watch did not accept the connection. Check the connection port.");
        check();String answer=c.shell("getprop ro.product.model; getprop ro.build.version.sdk; getprop ro.serialno; pm list features | grep android.hardware.type.watch; echo FACEPORT_PROBE_DONE");
        WatchProbe watch;try{watch=WatchProbe.parse(answer);}catch(IOException invalid){c.disconnect();throw invalid;}
        device=watch.model;watchSdk=watch.sdk;
        check();targetId=watch.serial;targetHost=host;connected=true;saveHost(host);getSharedPreferences("faceport",0).edit().putInt("port",port).apply();
        int remaining=cleanupPending();
        publish("Watch connected",device+" · Android API "+watchSdk+". You can now review and install an APK."+(remaining>0?" An earlier temporary upload still needs cleanup; reconnect to retry.":""),-1);
    }
    private void saveHost(String host){getSharedPreferences("faceport",0).edit().putString("host",host).apply();}
    private void install()throws Exception {
        if(!connected||client==null||!client.isConnected())throw new IOException("Connect your watch first");
        JSONObject apk=ApkStore.info(this);File file=ApkStore.file(this);
        if(!file.isFile()||apk.optString("package").isEmpty())throw new IOException("Choose an APK first");
        if(apk.optInt("minSdk",999)>watchSdk)throw new IOException("This APK requires Android API "+apk.optInt("minSdk")+"; this watch reports API "+watchSdk);
        publish("Checking APK","Verifying that the selected file has not changed…",-1);check();
        if(!ApkStore.digest(file).equals(apk.optString("sha256")))throw new IOException("The APK changed after review. Choose the file again.");
        String remote="/data/local/tmp/faceport-"+UUID.randomUUID().toString()+".apk";
        trackTemporary(remote);
        try {
            publish("Sending to watch","Starting file transfer…",0);client.push(file,remote,meter("Sending to watch"));check();
            publish("Installing","The watch is checking and installing "+apk.optString("label")+"…",-1);
            installSubmitted=true;
            String result=client.shell("pm install -r '"+remote+"'; echo FACEPORT_INSTALL_RC:$?",120000);
            if(result.matches("(?s).*\\bSuccess\\s*\nFACEPORT_INSTALL_RC:0\\s*$")) {
                installSubmitted=false;history("INSTALLED",result);
                publish("Installed",apk.optString("label")+" was accepted by "+device+". Open the app or select the face on your watch.",100);
            } else if(result.contains("FACEPORT_INSTALL_RC:")) {
                installSubmitted=false;throw new IOException(friendlyInstallError(result));
            } else throw new IOException("The watch did not return a complete installation result");
        } finally {
            boolean wasInterrupted=Thread.interrupted();
            if(client!=null&&client.isConnected())removeTemporary(remote);
            if(hasTemporary(remote)){
                detail+=" Temporary upload cleanup is pending. Reconnect to this watch to retry cleanup.";
                sendBroadcast(new Intent(UPDATE).setPackage(getPackageName()));
            }
            if(wasInterrupted)Thread.currentThread().interrupt();
        }
    }
    private synchronized JSONArray pending(){try{return new JSONArray(getSharedPreferences("faceport",0).getString("pendingUploads","[]"));}catch(Exception e){return new JSONArray();}}
    private synchronized void trackTemporary(String path)throws Exception{
        JSONArray p=pending();JSONObject row=new JSONObject();row.put("path",path);row.put("deviceId",targetId);row.put("host",targetHost);row.put("model",device);p.put(row);
        if(!getSharedPreferences("faceport",0).edit().putString("pendingUploads",p.toString()).commit())throw new IOException("Could not save transfer recovery information");
    }
    private synchronized boolean hasTemporary(String path){JSONArray p=pending();for(int i=0;i<p.length();i++)if(p.optJSONObject(i)!=null&&path.equals(p.optJSONObject(i).optString("path")))return true;return false;}
    private synchronized void forgetTemporary(String path){JSONArray p=pending(),next=new JSONArray();for(int i=0;i<p.length();i++){JSONObject row=p.optJSONObject(i);if(row!=null&&!path.equals(row.optString("path")))next.put(row);}getSharedPreferences("faceport",0).edit().putString("pendingUploads",next.toString()).commit();}
    private boolean removeTemporary(String path){
        if(!path.matches("/data/local/tmp/faceport-[a-f0-9-]{36}\\.apk"))return false;
        try{String answer=client.shell("rm -f '"+path+"'; echo FACEPORT_CLEAN_RC:$?",10000);if(answer.endsWith("FACEPORT_CLEAN_RC:0")){forgetTemporary(path);return true;}}catch(Exception ignored){}return false;
    }
    private int cleanupPending(){
        JSONArray p=pending();int remaining=0;
        for(int i=0;i<p.length();i++){JSONObject row=p.optJSONObject(i);if(row==null)continue;
            // A serial binds recovery to the same watch. Never wildcard-delete or trust a reused IP alone.
            if(!targetId.isEmpty()&&targetId.equals(row.optString("deviceId"))){
                if(cancelled||!removeTemporary(row.optString("path")))remaining++;
            }
        }return remaining;
    }
    private void disconnect()throws Exception {if(client!=null)client.disconnect();connected=false;device="No watch connected";publish("Disconnected","Turn off Wireless debugging on the watch when you are finished.",-1);}
    private void cancel(boolean timeout) {
        if(!busy)return;cancelled=true;timedOut=timeout;
        Thread t=workThread;if(t!=null)t.interrupt();
        new Thread(()->{ApkStore.cancelImport();if(client!=null)client.cancelStream();},"WatchBurner-cancel").start();
        publish("Stopping",installSubmitted?"The watch may finish an installation already started. Check its result before retrying.":"Stopping the current operation…",-1);
    }
    static String friendlyInstallError(String result) {
        String explain="The watch rejected this APK.";
        if(result.contains("UPDATE_INCOMPATIBLE"))explain="The installed app uses a different signing key. An update needs the original developer’s key; removing the existing app can erase its data.";
        else if(result.contains("VERSION_DOWNGRADE"))explain="This APK is older than the installed version. WatchBurner does not force downgrades.";
        else if(result.contains("INSUFFICIENT_STORAGE"))explain="The watch needs more free space.";
        else if(result.contains("NO_MATCHING_ABIS"))explain="This APK was built for a different processor. Ask for a compatible Wear OS APK.";
        else if(result.contains("OLDER_SDK"))explain="This APK needs a newer Android version than your watch provides.";
        else if(result.contains("MISSING_SPLIT"))explain="This download is missing required APK splits. Ask for a standalone APK.";
        else if(result.contains("PARSE")||result.contains("INVALID_APK"))explain="The watch could not validate this APK. Download it again from its developer.";
        return explain+"\n\nWatch response:\n"+result;
    }
    private String error(Throwable e) {if(timedOut)return "The operation timed out. Check Wi-Fi and the current port on your watch.";if(cancelled)return "Cancelled by you.";String m=e.getMessage();if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName();return m;}
    private synchronized void history(String outcome,String message) {
        try {SharedPreferences p=getSharedPreferences("faceport",0);JSONArray old=new JSONArray(p.getString("history","[]")),next=new JSONArray();
            JSONObject row=ApkStore.info(this);row.put("time",System.currentTimeMillis());row.put("outcome",outcome);row.put("message",message);row.put("device",device);next.put(row);
            for(int i=0;i<Math.min(old.length(),39);i++)next.put(old.get(i));p.edit().putString("history",next.toString()).commit();
        } catch(Exception ignored){}
    }
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){current=null;connected=false;cancel(true);worker.shutdownNow();watchdog.shutdownNow();if(client!=null)new Thread(()->{try{client.disconnect();}catch(Exception ignored){}}).start();if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();super.onDestroy();}
}
