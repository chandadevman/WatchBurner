package com.tenvyro.faceport;

/** User-entered watch address. Parsing never resolves a hostname or opens a socket. */
public final class WatchEndpoint {
    public final String host;
    public final int port;

    private WatchEndpoint(String host, int port) {
        this.host = host;
        this.port = port;
    }

    /** Accepts a plain IPv4 address or the IP:port shown by Wireless debugging. */
    public static WatchEndpoint parse(String hostText, String portText) {
        String address = trimmed(hostText);
        String separatePort = trimmed(portText);
        if (address.length() == 0) {
            throw new IllegalArgumentException("Enter the IP address shown on your watch.");
        }
        if (address.indexOf('/') >= 0 || address.indexOf('\\') >= 0
                || address.indexOf('?') >= 0 || address.indexOf('#') >= 0) {
            throw new IllegalArgumentException("Enter only the watch's IP address or IP:port, without a web address or path.");
        }
        String embeddedPort = null;
        int colon = address.indexOf(':');
        if (colon >= 0) {
            if (colon != address.lastIndexOf(':') || address.indexOf('[') >= 0
                    || address.indexOf(']') >= 0) {
                throw new IllegalArgumentException("This beta needs an IPv4 address, such as 192.168.1.24. IPv6 is not supported yet.");
            }
            embeddedPort = address.substring(colon + 1);
            address = address.substring(0, colon);
        }
        validateIpv4(address);
        Integer pastedPort = embeddedPort == null ? null : Integer.valueOf(parsePort(embeddedPort));
        if (separatePort.length() == 0) {
            if (pastedPort == null) {
                throw new IllegalArgumentException("Enter the port shown on your watch, or paste the complete IP:port.");
            }
            return new WatchEndpoint(address, pastedPort.intValue());
        }
        int port = parsePort(separatePort);
        if (pastedPort != null && pastedPort.intValue() != port) {
            throw new IllegalArgumentException("The pasted IP:port and Port field do not match. Clear the Port field to use the pasted port, or enter only the IP address.");
        }
        return new WatchEndpoint(address, port);
    }

    /** Trims outside whitespace only; codes are neither stored nor included in errors. */
    public static String parsePairingCode(String code) {
        String result = trimmed(code);
        if (result.length() != 6 || !asciiDigits(result)) {
            throw new IllegalArgumentException("Enter the current six-digit pairing code from your watch, with no spaces between digits.");
        }
        return result;
    }

    private static void validateIpv4(String address) {
        String[] octets = address.split("\\.", -1);
        if (octets.length != 4) {
            throw invalidAddress();
        }
        for (String octet : octets) {
            if (octet.length() == 0 || octet.length() > 3 || !asciiDigits(octet)) {
                throw invalidAddress();
            }
            if (octet.length() > 1 && octet.charAt(0) == '0') {
                throw new IllegalArgumentException("Enter each IP number without leading zeros, for example 192.168.1.24.");
            }
            if (Integer.parseInt(octet) > 255) {
                throw invalidAddress();
            }
        }
    }

    private static int parsePort(String port) {
        if (port.length() == 0 || port.length() > 5 || !asciiDigits(port)) {
            throw new IllegalArgumentException("Enter a port number from 1 to 65535, exactly as shown on your watch.");
        }
        int value = Integer.parseInt(port);
        if (value < 1 || value > 65535) {
            throw new IllegalArgumentException("Enter a port number from 1 to 65535, exactly as shown on your watch.");
        }
        return value;
    }

    private static boolean asciiDigits(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        return true;
    }

    private static String trimmed(String text) {
        if (text == null) return "";
        int start = 0;
        int end = text.length();
        while (start < end && Character.isWhitespace(text.charAt(start))) start++;
        while (end > start && Character.isWhitespace(text.charAt(end - 1))) end--;
        return text.substring(start, end);
    }

    private static IllegalArgumentException invalidAddress() {
        return new IllegalArgumentException("Enter the watch's IPv4 address as four numbers from 0 to 255, such as 192.168.1.24.");
    }
}
