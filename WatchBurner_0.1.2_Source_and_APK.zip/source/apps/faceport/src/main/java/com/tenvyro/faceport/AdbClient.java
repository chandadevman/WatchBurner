package com.tenvyro.faceport;

import android.content.Context;
import android.os.Build;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.util.concurrent.TimeUnit;

final class AdbClient extends AbsAdbConnectionManager {
    private final Identity identity;
    private volatile AdbStream activeStream;
    AdbClient(Context context) throws Exception {
        identity = new Identity(context); setApi(Build.VERSION.SDK_INT); setTimeout(20, TimeUnit.SECONDS);
    }
    @Override protected PrivateKey getPrivateKey() { return identity.key; }
    @Override protected Certificate getCertificate() { return identity.certificate; }
    @Override protected String getDeviceName() { return "ReapTyc WatchBurner"; }

    String shell(String command) throws Exception { return shell(command,30000); }
    String shell(String command,long timeoutMs) throws Exception {
        AdbStream stream = openStream("shell:" + command); activeStream = stream;
        java.util.Timer timer = new java.util.Timer("WatchBurner-shell-timeout",true);
        java.util.concurrent.atomic.AtomicBoolean timedOut = new java.util.concurrent.atomic.AtomicBoolean();
        timer.schedule(new java.util.TimerTask(){public void run(){timedOut.set(true);try{stream.close();}catch(Exception ignored){}}},timeoutMs);
        try (AdbStream s = stream; InputStream in = s.openInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] bytes = new byte[2048]; int n;
            while ((n = in.read(bytes)) != -1) {
                out.write(bytes,0,n);
                if (out.size() > 131072) throw new IOException("Watch response exceeded the expected size");
            }
            if(timedOut.get())throw new java.net.SocketTimeoutException("The watch did not finish its response in time");
            return out.toString("UTF-8").replace("\r", "").trim();
        } finally { timer.cancel(); activeStream = null; }
    }
    interface Progress { void update(long sent, long total); void check() throws IOException; }
    void push(File apk, String remote, Progress progress) throws Exception {
        AdbStream stream = openStream("sync:"); activeStream = stream;
        try { pushStream(stream,apk,remote,progress); } finally { activeStream = null; }
    }
    static void pushStream(AdbStream stream,File apk,String remote,Progress progress) throws Exception {
        try (AdbStream s = stream; InputStream response = s.openInputStream(); FileInputStream file = new FileInputStream(apk)) {
            OutputStream out = s.openOutputStream();
            byte[] path = (remote+",33188").getBytes(StandardCharsets.UTF_8); // regular file, 0644
            packet(out,"SEND",path.length); out.write(path); out.flush();
            byte[] bytes = new byte[2048]; int n; long sent = 0;
            while ((n = file.read(bytes)) != -1) {
                progress.check(); packet(out,"DATA",n); out.write(bytes,0,n); out.flush(); sent += n; progress.update(sent,apk.length());
            }
            packet(out,"DONE",(int)(System.currentTimeMillis()/1000)); out.flush();
            byte[] header = new byte[8]; readFully(response,header);
            String id = new String(header,0,4,StandardCharsets.US_ASCII); int count = littleInt(header,4);
            if ("FAIL".equals(id)) {
                if (count < 0 || count > 65536) throw new IOException("Unexpected watch transfer error");
                byte[] message = new byte[count]; readFully(response,message); throw new IOException(new String(message,StandardCharsets.UTF_8));
            }
            if (!"OKAY".equals(id) || count != 0) throw new IOException("The watch did not confirm the completed transfer");
        }
    }
    void cancelStream() { AdbStream stream = activeStream; if (stream != null) try { stream.close(); } catch (IOException ignored) {} }
    static void packet(OutputStream out, String id, int number) throws IOException {
        byte[] h = new byte[8]; byte[] tag = id.getBytes(StandardCharsets.US_ASCII); System.arraycopy(tag,0,h,0,4);
        for (int i=0;i<4;i++) h[4+i]=(byte)(number >>> (i*8)); out.write(h);
    }
    static int littleInt(byte[] bytes,int offset) { return (bytes[offset]&255)|((bytes[offset+1]&255)<<8)|((bytes[offset+2]&255)<<16)|((bytes[offset+3]&255)<<24); }
    static void readFully(InputStream in, byte[] bytes) throws IOException {
        int offset=0,n; while (offset<bytes.length) { n=in.read(bytes,offset,bytes.length-offset); if(n<0) throw new EOFException("The watch disconnected before confirming the transfer"); offset+=n; }
    }
}
