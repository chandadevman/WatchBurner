package com.tenvyro.faceport;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.text.DateFormat;
import java.util.*;
import org.json.*;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(19,24,32), CARD=Color.rgb(29,38,52), TEXT=Color.rgb(245,247,250),
            MUTED=Color.rgb(186,198,214), GOLD=Color.rgb(240,196,106), BLUE=Color.rgb(111,173,255), LINE=Color.rgb(53,68,89);
    private static final int HOST=1001, PAIR_PORT=1002, CONNECT_PORT=1003, PAIR_CODE=1004;
    private LinearLayout body,statusBox; private ScrollView scroll;
    private TextView statusTitle,statusDetail,statusPercent; private ProgressBar progressBar; private Button cancelButton;
    private String tab="Install",renderedTab="Install",hostDraft="",pairDraft="",connectDraft="",codeDraft="";
    private EditText host,connectPort,pairPort,code;
    private boolean welcome,pairExpanded,seenBusy,seenConnected,seenNotifications,destroyed;
    private String seenApk="",seenState="";
    private final Map<String,Integer> scrollPositions=new HashMap<>();
    private final BroadcastReceiver updates=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refreshFromService();}};
    private SharedPreferences prefs(){return getSharedPreferences("faceport",0);}
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        hostDraft=prefs().getString("uiHostDraft",prefs().getString("host",""));
        pairDraft=prefs().getString("uiPairPortDraft","");
        connectDraft=prefs().getString("uiConnectPortDraft",prefs().getInt("port",0)>0?Integer.toString(prefs().getInt("port",0)):"");
        welcome=!prefs().getBoolean("uiWelcomeSeen",false);pairExpanded=!prefs().getBoolean("uiPairedBefore",false);
        if(saved!=null){tab=saved.getString("tab","Install");hostDraft=saved.getString("hostDraft",hostDraft);pairDraft=saved.getString("pairDraft",pairDraft);connectDraft=saved.getString("connectDraft",connectDraft);pairExpanded=saved.getBoolean("pairExpanded",pairExpanded);for(String name:new String[]{"Install","Connect","History","Help"})scrollPositions.put(name,saved.getInt("scroll"+name,0));}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(updates,new IntentFilter(FacePortService.UPDATE),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updates,new IntentFilter(FacePortService.UPDATE));
        render(false);
    }
    @Override protected void onResume(){super.onResume();if(body!=null)refreshFromService();}
    @Override protected void onPause(){captureDrafts();saveDrafts();super.onPause();}
    @Override protected void onStop(){codeDraft="";if(code!=null)code.setText("");super.onStop();}
    @Override protected void onSaveInstanceState(Bundle b){captureDrafts();saveDrafts();rememberScroll();super.onSaveInstanceState(b);b.putString("tab",tab);b.putString("hostDraft",hostDraft);b.putString("pairDraft",pairDraft);b.putString("connectDraft",connectDraft);b.putBoolean("pairExpanded",pairExpanded);for(Map.Entry<String,Integer> e:scrollPositions.entrySet())b.putInt("scroll"+e.getKey(),e.getValue());}
    @Override public void onDestroy(){destroyed=true;try{unregisterReceiver(updates);}catch(Exception ignored){}super.onDestroy();}
    private void captureDrafts(){if(host!=null)hostDraft=host.getText().toString();if(pairPort!=null)pairDraft=pairPort.getText().toString();if(connectPort!=null)connectDraft=connectPort.getText().toString();if(code!=null)codeDraft=code.getText().toString();}
    private void saveDrafts(){prefs().edit().putString("uiHostDraft",hostDraft).putString("uiPairPortDraft",pairDraft).putString("uiConnectPortDraft",connectDraft).apply();}
    private void rememberScroll(){if(scroll!=null)scrollPositions.put(renderedTab,scroll.getScrollY());}
    private boolean notificationsAllowed(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    private void navigate(String destination){captureDrafts();saveDrafts();hideKeyboard();tab=destination;render(false);}
    private void refreshFromService(){
        if(destroyed||isFinishing())return;
        boolean justPaired="Paired".equals(FacePortService.state)&&!"Paired".equals(seenState);
        if(justPaired){prefs().edit().putBoolean("uiPairedBefore",true).apply();pairExpanded=false;}
        String apk=ApkStore.info(this).optString("sha256");
        if(seenBusy!=FacePortService.busy||seenConnected!=FacePortService.connected||!seenApk.equals(apk)||seenNotifications!=notificationsAllowed()||justPaired){render(true);}
        else{updateStatus();seenState=FacePortService.state;}
    }
    private int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+.5f);}
    private GradientDrawable rounded(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);v.setLineSpacing(dp(3),1);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private void space(LinearLayout parent,int height){parent.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
    private void paragraph(LinearLayout parent,String value){parent.addView(text(value,15,MUTED,false));space(parent,10);}
    private LinearLayout card(String eyebrow,String title,String subtitle){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(18),dp(18),dp(18));GradientDrawable background=rounded(CARD,20);background.setStroke(dp(1),LINE);c.setBackground(background);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);body.addView(c,p);
        if(eyebrow!=null){c.addView(text(eyebrow.toUpperCase(Locale.US),11,GOLD,true));space(c,8);}
        if(title!=null){TextView heading=text(title,21,TEXT,true);if(Build.VERSION.SDK_INT>=28)heading.setAccessibilityHeading(true);c.addView(heading);space(c,8);}
        if(subtitle!=null)paragraph(c,subtitle);return c;
    }
    private Button newButton(String label,boolean primary,Runnable click){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(primary?BG:TEXT);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x337FAFFF),rounded(primary?GOLD:LINE,13),null));b.setMinHeight(dp(52));b.setMinimumHeight(dp(52));b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(12),dp(12),dp(12),dp(12));b.setOnClickListener(v->click.run());return b;
    }
    private Button button(LinearLayout parent,String label,boolean primary,Runnable click){Button b=newButton(label,primary,click);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);parent.addView(b,p);return b;}
    private void enable(Button b,boolean enabled){b.setEnabled(enabled);b.setAlpha(enabled?1f:.45f);}
    private void render(boolean keepFocus){
        if(destroyed||isFinishing())return;
        View focused=getCurrentFocus();int focusId=keepFocus&&focused instanceof EditText?focused.getId():-1;
        int selection=focusId!=-1?((EditText)focused).getSelectionStart():-1;
        captureDrafts();rememberScroll();host=null;pairPort=null;connectPort=null;code=null;renderedTab=tab;
        FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(BG);setContentView(frame);
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setSaveEnabled(false);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels,dp(640)),-1,Gravity.TOP|Gravity.CENTER_HORIZONTAL);frame.addView(scroll,sp);
        frame.setOnApplyWindowInsetsListener((v,insets)->{frame.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)scroll.getLayoutParams();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-insets.getSystemWindowInsetLeft()-insets.getSystemWindowInsetRight(),dp(640));scroll.setLayoutParams(lp);return insets;});frame.requestApplyInsets();
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(18),dp(18),dp(18),dp(24));page.setFocusableInTouchMode(true);scroll.addView(page);
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);ImageView mark=new ImageView(this);mark.setImageResource(R.drawable.ic_faceport);mark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(52),dp(52));ip.rightMargin=dp(12);heading.addView(mark,ip);
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.addView(text("ReapTyc",12,BLUE,true));words.addView(text("WatchBurner",27,TEXT,true));heading.addView(words,new LinearLayout.LayoutParams(0,-2,1));page.addView(heading);space(page,10);
        page.addView(text("Watch Apps & Faces Installer",14,MUTED,false));space(page,6);page.addView(text("BETA 0.1.2  •  PHONE INSTALLER",10,GOLD,true));space(page,20);
        String[] tabs={"Install","Connect","History","Help"};int columns=getResources().getConfiguration().screenWidthDp<360||getResources().getConfiguration().fontScale>=1.3f?2:4;
        for(int i=0;i<tabs.length;){LinearLayout row=new LinearLayout(this);for(int j=0;j<columns&&i<tabs.length;j++,i++){String name=tabs[i];Button t=newButton(name,tab.equals(name),()->navigate(name));t.setTextSize(13);t.setPadding(dp(6),dp(10),dp(6),dp(10));t.setSelected(tab.equals(name));t.setContentDescription(name+(tab.equals(name)?", selected":""));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);if(j>0)p.leftMargin=dp(6);row.addView(t,p);}page.addView(row);space(page,6);}space(page,10);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);page.addView(body);
        statusBox=card(null,null,null);statusTitle=text("",20,TEXT,true);statusTitle.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);statusBox.addView(statusTitle);space(statusBox,8);statusDetail=text("",15,MUTED,false);statusBox.addView(statusDetail);
        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progressBar.setProgressTintList(ColorStateList.valueOf(BLUE));progressBar.setIndeterminateTintList(ColorStateList.valueOf(BLUE));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(8));pp.topMargin=dp(16);statusBox.addView(progressBar,pp);progressBar.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        statusPercent=text("",13,BLUE,true);statusBox.addView(statusPercent);cancelButton=button(statusBox,"Cancel operation",false,()->start("cancel",null));updateStatus();
        if(welcome&&"Install".equals(tab))welcome();else if("Connect".equals(tab))connection();else if("History".equals(tab))history();else if("Help".equals(tab))help();else install();
        TextView foot=text("Local transfer • No account required\nBuilt by Tenvyro",11,MUTED,false);foot.setGravity(Gravity.CENTER);page.addView(foot);
        seenBusy=FacePortService.busy;seenConnected=FacePortService.connected;seenApk=ApkStore.info(this).optString("sha256");seenNotifications=notificationsAllowed();seenState=FacePortService.state;
        final ScrollView currentScroll=scroll;final int y=scrollPositions.containsKey(tab)?scrollPositions.get(tab):0;final int restoreId=focusId,restoreSelection=selection;
        page.requestFocus();currentScroll.post(()->{if(destroyed||scroll!=currentScroll)return;View field=restoreId!=-1?findViewById(restoreId):null;if(field instanceof EditText&&field.isEnabled()){field.requestFocus();EditText e=(EditText)field;e.setSelection(Math.min(Math.max(0,restoreSelection),e.length()));}currentScroll.scrollTo(0,y);});
    }
    private void updateStatus(){
        if(statusBox==null)return;boolean busy=FacePortService.busy;statusBox.setVisibility(busy||!"Ready".equals(FacePortService.state)?View.VISIBLE:View.GONE);
        if(!FacePortService.state.contentEquals(statusTitle.getText()))statusTitle.setText(FacePortService.state);
        statusDetail.setText(FacePortService.detail);progressBar.setVisibility(busy?View.VISIBLE:View.GONE);statusPercent.setVisibility(busy?View.VISIBLE:View.GONE);cancelButton.setVisibility(busy?View.VISIBLE:View.GONE);
        if(busy){int progress=FacePortService.progress;progressBar.setIndeterminate(progress<0);progressBar.setMax(100);progressBar.setProgress(Math.max(0,progress));statusPercent.setText(progress<0?"Working…":progress+"% transferred");}
    }
    private void finishWelcome(String destination){welcome=false;prefs().edit().putBoolean("uiWelcomeSeen",true).apply();pairExpanded=true;navigate(destination);}
    private void welcome(){
        LinearLayout c=card("Welcome to WatchBurner","Your phone is the installer.","Keep WatchBurner on this phone. It sends the apps and watch faces you choose directly to your watch over Wi-Fi.");
        paragraph(c,"1. Pair and connect your watch.\n2. Choose a watch APK on your phone.\n3. Review it, then send and install.");
        paragraph(c,"You don’t need to install WatchBurner on the watch first.");
        button(c,"Set up my watch",true,()->finishWelcome("Connect"));button(c,"Open installer",false,()->finishWelcome("Install"));notificationCard();
    }
    private void notificationCard(){
        if(Build.VERSION.SDK_INT<33||notificationsAllowed())return;
        LinearLayout c=card("Optional","See progress outside the app","Allow notifications to follow a transfer while using another app. You can keep using WatchBurner without them.");
        button(c,"Enable progress notifications",false,()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44));
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==44)render(true);}
    private void install(){
        JSONObject apk=ApkStore.info(this);boolean has=ApkStore.file(this).isFile()&&!apk.optString("package").isEmpty();
        LinearLayout connection=card("1 · Your watch",FacePortService.connected?FacePortService.device:"Connect your watch",FacePortService.connected?"Connected over Wi-Fi. Ready for your next APK.":"Pair once, then connect using the current port on your watch’s Wireless debugging screen.");
        button(connection,FacePortService.connected?"Connection settings":"Connect watch",!FacePortService.connected,()->navigate("Connect"));
        LinearLayout choose=card("2 · Your APK",has?apk.optString("label","Selected APK"):"Choose an app or face",has?apk.optString("name"):"Choose a standalone .apk file made for Wear OS. Your original file stays where it is.");
        if(has){paragraph(choose,"Version "+apk.optString("version")+" · "+String.format(Locale.US,"%.1f MB",apk.optLong("bytes")/1048576d));paragraph(choose,apk.optString("package"));if(!apk.optBoolean("watch"))paragraph(choose,"Watch support is not declared in this APK. Check that its developer supports Wear OS before installing.");button(choose,"Review file details",false,()->apkDetails(apk));}
        enable(button(choose,has?"Choose a different APK":"Choose APK",!has,this::pick),!FacePortService.busy);
        LinearLayout go=card("3 · Send & install","One final check","WatchBurner sends your selected APK to the watch, which checks and installs it. Choose an installed face in the watch’s face picker afterward.");
        if(!FacePortService.busy&&(!has||!FacePortService.connected))paragraph(go,!has&&!FacePortService.connected?"Connect your watch and choose an APK to continue.":!has?"Choose an APK to continue.":"Connect your watch to continue.");
        enable(button(go,"Install on watch",true,this::confirmInstall),has&&FacePortService.connected&&!FacePortService.busy);
        if(has)enable(button(go,"Remove selected file",false,()->new AlertDialog.Builder(this).setTitle("Remove selected APK?").setMessage("This removes WatchBurner’s local copy. Your original file and installed watch apps stay in place.").setNegativeButton("Keep",null).setPositiveButton("Remove",(d,w)->{if(FacePortService.busy){toast("Wait for the current operation to finish");return;}File f=ApkStore.file(this);if(f.exists()&&!f.delete()){toast("Could not remove the local copy. Please try again.");return;}prefs().edit().remove("apk").apply();render(false);}).show()),!FacePortService.busy);
    }
    private void apkDetails(JSONObject apk){
        String detail="Package: "+apk.optString("package")+"\nVersion: "+apk.optString("version")+" ("+apk.optLong("versionCode")+")\nMinimum Android API: "+apk.optInt("minSdk")+"\nTarget Android API: "+apk.optInt("targetSdk")+"\nWatch feature declared: "+(apk.optBoolean("watch")?"Yes":"No")+"\n\nFile SHA-256\n"+apk.optString("sha256")+"\n\nSigner SHA-256\n"+apk.optString("signer","Not available")+"\n\nRequested permissions\n";
        JSONArray permissions=apk.optJSONArray("permissions");if(permissions==null||permissions.length()==0)detail+="None declared";else for(int i=0;i<permissions.length();i++)detail+=permissions.optString(i)+"\n";
        detail+="\nFingerprints identify this file and declared signer. They are not a malware scan. The watch verifies APK signatures during installation.";showText("APK details",detail);
    }
    private void pick(){if(FacePortService.busy)return;hideKeyboard();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.android.package-archive","application/octet-stream"});try{startActivityForResult(i,100);}catch(ActivityNotFoundException e){toast("No file picker is available on this phone");}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==100&&result==RESULT_OK&&data!=null&&data.getData()!=null){Bundle b=new Bundle();b.putString("uri",data.getData().toString());start("import",b);}}
    private void confirmInstall(){
        if(FacePortService.busy||!FacePortService.connected)return;JSONObject apk=ApkStore.info(this);final String expected=apk.optString("sha256");final String watch=FacePortService.device;
        new AlertDialog.Builder(this).setTitle("Install on "+watch+"?").setMessage(apk.optString("label")+"\n"+apk.optString("package")+"\nVersion "+apk.optString("version")+"\n\nContinue if you trust this APK’s source. An existing app with this package may be updated.").setNegativeButton("Cancel",null).setPositiveButton("Send & install",(d,w)->{if(!FacePortService.connected||!watch.equals(FacePortService.device)||!expected.equals(ApkStore.info(this).optString("sha256"))){toast("Your watch or file changed. Review the selection again.");return;}start("install",null);}).show();
    }
    private EditText input(LinearLayout parent,int id,String label,String value,String hint,boolean number){
        TextView caption=text(label,13,MUTED,true);caption.setLabelFor(id);parent.addView(caption);EditText e=new EditText(this);e.setId(id);e.setSaveEnabled(false);e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);e.setText(value);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(17);e.setSingleLine(true);e.setPadding(dp(13),dp(14),dp(13),dp(14));e.setMinHeight(dp(54));GradientDrawable background=rounded(BG,11);background.setStroke(dp(1),LINE);e.setBackground(background);e.setInputType(number?InputType.TYPE_CLASS_NUMBER:InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);e.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_NEXT|android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI|android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);e.setSelectAllOnFocus(true);e.setEnabled(!FacePortService.busy);
        if(id==PAIR_CODE)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){String v=s.toString();if(id==HOST)hostDraft=v;else if(id==PAIR_PORT)pairDraft=v;else if(id==CONNECT_PORT)connectDraft=v;else codeDraft=v;}public void afterTextChanged(Editable s){}});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(6);p.bottomMargin=dp(16);parent.addView(e,p);return e;
    }
    private void connection(){
        LinearLayout top=card("Watch connection","Start on the same Wi-Fi","On your watch, enable ADB debugging and Wireless debugging in Developer options. Keep both devices on the same trusted Wi-Fi.");
        host=input(top,HOST,"Watch IP address",hostDraft,"192.168.1.25 or IP:port",false);
        button(top,"Show setup steps",false,()->navigate("Help"));button(top,"Phone Wi-Fi settings",false,()->open(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        LinearLayout pair=card("A · Pair once",pairExpanded?"Pair a new device":"Already paired?",pairExpanded?"Open Pair new device on your watch. Keep its six-digit code visible while pairing.":"If this phone is already paired, go straight to Connect below.");
        if(pairExpanded){pairPort=input(pair,PAIR_PORT,"Pairing port",pairDraft,"From Pair new device",true);code=input(pair,PAIR_CODE,"Six-digit pairing code",codeDraft,"Shown on your watch",true);paragraph(pair,"Pairing codes expire. Use the code currently on your watch.");
            enable(button(pair,"Pair with watch",true,()->{Bundle b=connectionArgs(pairPort);if(b==null)return;String pairing;try{pairing=WatchEndpoint.parsePairingCode(code.getText().toString());}catch(IllegalArgumentException e){code.setError(e.getMessage());code.requestFocus();return;}b.putString("code",pairing);code.setText("");codeDraft="";start("pair",b);}),!FacePortService.busy);
            enable(button(pair,"Already paired? Show connection",false,()->{pairExpanded=false;codeDraft="";code.setText("");render(false);}),!FacePortService.busy);
        }else enable(button(pair,"Pair a new watch or pair again",false,()->{pairExpanded=true;render(false);}),!FacePortService.busy);
        LinearLayout connect=card("B · Connect each session","Connect to your watch","Return to the main Wireless debugging screen on the watch. Use its connection port here; it is usually different from the pairing port.");
        connectPort=input(connect,CONNECT_PORT,"Connection port",connectDraft,"From Wireless debugging",true);
        enable(button(connect,FacePortService.connected?"Reconnect":"Connect watch",true,()->{Bundle b=connectionArgs(connectPort);if(b!=null)start("connect",b);}),!FacePortService.busy);
        if(FacePortService.connected){space(connect,12);paragraph(connect,"Connected to "+FacePortService.device);button(connect,"Choose an APK",true,()->{welcome=false;prefs().edit().putBoolean("uiWelcomeSeen",true).apply();navigate("Install");});enable(button(connect,"Disconnect",false,()->start("disconnect",null)),!FacePortService.busy);}
        paragraph(connect,"The port can change when Wireless debugging restarts. Turn it off on the watch when you’re finished.");
    }
    private Bundle connectionArgs(EditText port){
        host.setError(null);port.setError(null);
        try{WatchEndpoint endpoint=WatchEndpoint.parse(host.getText().toString(),port.getText().toString());host.setText(endpoint.host);port.setText(Integer.toString(endpoint.port));captureDrafts();saveDrafts();Bundle b=new Bundle();b.putString("host",endpoint.host);b.putInt("port",endpoint.port);return b;}
        catch(IllegalArgumentException e){port.setError(e.getMessage());toast(e.getMessage());return null;}
    }
    private void history(){
        JSONArray items;try{items=new JSONArray(prefs().getString("history","[]"));}catch(Exception e){items=new JSONArray();}
        if(items.length()==0){LinearLayout c=card("Your activity","Your first install starts here","Completed, failed and cancelled install attempts appear here. WatchBurner waits for the watch’s result before reporting success.");button(c,"Open installer",true,()->navigate("Install"));return;}
        LinearLayout actions=card(null,"Installation history","Your latest 40 attempts are kept on this phone.");button(actions,"Share diagnostic history",false,this::shareHistory);
        enable(button(actions,"Clear history",false,()->new AlertDialog.Builder(this).setTitle("Clear installation history?").setMessage("This removes local records. Installed apps stay on the watch.").setNegativeButton("Keep",null).setPositiveButton("Clear",(d,w)->{if(FacePortService.busy){toast("Wait for the current operation to finish");return;}prefs().edit().remove("history").apply();render(false);}).show()),!FacePortService.busy);
        for(int i=0;i<items.length();i++){JSONObject row=items.optJSONObject(i);if(row==null)continue;LinearLayout c=card(row.optString("outcome"),row.optString("label","APK"),DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(row.optLong("time")))+" · "+row.optString("device"));paragraph(c,row.optString("package")+" · "+row.optString("version"));button(c,"View result",false,()->showText("Watch result",row.optString("message")+"\n\nFile SHA-256\n"+row.optString("sha256")));}
    }
    private void shareHistory(){String raw=prefs().getString("history","[]");Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,"WatchBurner installation diagnostics").putExtra(Intent.EXTRA_TEXT,raw);open(Intent.createChooser(i,"Share diagnostics"));}
    private void help(){
        LinearLayout setup=card("Getting started","From phone to watch","Install WatchBurner on your Android phone. No WatchBurner app is needed on the watch. Your chosen Wear OS apps and watch faces go to the watch.");
        paragraph(setup,"1. Put the phone and watch on the same trusted Wi-Fi. Keep the watch charging during a large transfer.");
        paragraph(setup,"2. On Galaxy Watch 6, open Settings → About watch → Software information. Tap Software version five times to enable Developer options. Menu names may vary with updates.");
        paragraph(setup,"3. Open Developer options. Enable ADB debugging and Wireless debugging. Open Pair new device. In WatchBurner’s Connect tab, enter the IP, pairing port and six-digit code, then tap Pair with watch.");
        paragraph(setup,"4. Return to the watch’s main Wireless debugging screen. Enter that screen’s connection port and tap Connect watch.");
        paragraph(setup,"5. Open Install, choose your APK and tap Install on watch. Review the confirmation, then send. After success, find apps in the watch’s app list; choose installed faces in its face picker.");
        button(setup,"Go to watch connection",true,()->navigate("Connect"));button(setup,"Replay welcome",false,()->{welcome=true;navigate("Install");});
        LinearLayout troubleshooting=card("Quick fixes","If something stops",null);
        paragraph(troubleshooting,"Can’t connect? Use the connection port from the main Wireless debugging screen. Check that the watch stayed on Wi-Fi; toggle Wireless debugging and use its new port. Guest Wi-Fi may block device-to-device traffic.");
        paragraph(troubleshooting,"Pairing expired? Open a fresh code on the watch. Codes are only used for pairing and are never saved in history. Leaving the app clears a code you haven’t submitted.");
        paragraph(troubleshooting,"Update rejected? An update must use the same package and signing key. WatchBurner does not remove existing apps or bypass signing checks.");
        paragraph(troubleshooting,"Face installed but missing? Its format must be supported by the watch’s OS. Newer Wear OS releases restrict legacy watch-face engines. A successful APK install does not guarantee a usable face.");
        paragraph(troubleshooting,"Cancelled during installation? The watch may already be finishing the install. Check the watch before retrying. Cancelling a transfer does not uninstall an app.");
        notificationCard();LinearLayout info=card("About WatchBurner","Built by Tenvyro","ReapTyc WatchBurner · Version 0.1.2 beta");
        paragraph(info,"IPv4 Wi-Fi connections · One standalone APK at a time · Files up to 512 MB · No account or cloud upload");
        paragraph(info,"Pairing uses Android’s debugging connection with your approval. Turn off Wireless debugging when done. APK compatibility depends on the app and your watch’s OS.");
        button(info,"Official Wear OS setup guide",false,()->open(new Intent(Intent.ACTION_VIEW,Uri.parse("https://developer.android.com/training/wearables/get-started/debug-wifi"))));
        button(info,"Open-source notices",false,()->{try(InputStream in=getAssets().open("THIRD_PARTY_NOTICES.txt");ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);showText("Open-source notices",out.toString("UTF-8"));}catch(Exception e){showText("Open-source notices","See the complete THIRD_PARTY_NOTICES and license files in the source package.");}});
    }
    private void showText(String title,String value){ScrollView scroller=new ScrollView(this);TextView t=text(value,15,TEXT,false);t.setPadding(dp(20),dp(16),dp(20),dp(16));t.setTextIsSelectable(true);scroller.addView(t);new AlertDialog.Builder(this).setTitle(title).setView(scroller).setPositiveButton("Done",null).show();}
    private void open(Intent intent){try{startActivity(intent);}catch(ActivityNotFoundException e){toast("No app is available to open this. See the included setup guide.");}}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private void hideKeyboard(){View focused=getCurrentFocus();if(focused!=null)((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(focused.getWindowToken(),0);}
    private void start(String action,Bundle args){if(FacePortService.busy&&!"cancel".equals(action)){toast("Wait for the current operation to finish");return;}captureDrafts();saveDrafts();hideKeyboard();try{FacePortService.start(this,action,args);}catch(Exception e){toast("Could not start: "+e.getMessage());}}
}
