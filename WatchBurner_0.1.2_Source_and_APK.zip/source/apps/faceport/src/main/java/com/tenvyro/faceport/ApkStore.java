package com.tenvyro.faceport;

import android.content.Context;
import android.content.pm.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.content.res.AssetFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;
import java.security.MessageDigest;
import org.json.*;

final class ApkStore {
    static final long MAX_BYTES = 512L*1024*1024;
    private static volatile CancellationSignal importSignal;
    private static volatile Closeable importStream;
    static void cancelImport(){CancellationSignal signal=importSignal;if(signal!=null)signal.cancel();Closeable stream=importStream;if(stream!=null)try{stream.close();}catch(Exception ignored){}}
    static File file(Context c) { return new File(c.getFilesDir(),"selected.apk"); }
    static JSONObject info(Context c) {
        try { return new JSONObject(c.getSharedPreferences("faceport",0).getString("apk","{}")); }
        catch(Exception e) { return new JSONObject(); }
    }
    static String digest(File file) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(file)) { byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n); }
        return hex(md.digest());
    }
    static String hex(byte[] bytes) { StringBuilder b=new StringBuilder();for(byte n:bytes)b.append(String.format(java.util.Locale.US,"%02x",n&255));return b.toString(); }
    static JSONObject importApk(Context context,Uri uri,AdbClient.Progress progress) throws Exception {
        CancellationSignal signal=new CancellationSignal();importSignal=signal;
        try{return importImpl(context,uri,progress,signal);}finally{importSignal=null;importStream=null;}
    }
    private static JSONObject importImpl(Context context,Uri uri,AdbClient.Progress progress,CancellationSignal signal) throws Exception {
        String name="Selected APK";long reported=-1;
        progress.check();
        try(Cursor cursor=context.getContentResolver().query(uri,null,null,null,null,signal)) {
            if(cursor!=null&&cursor.moveToFirst()) {
                int n=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME),s=cursor.getColumnIndex(OpenableColumns.SIZE);
                if(n>=0)name=cursor.getString(n);if(s>=0&&!cursor.isNull(s))reported=cursor.getLong(s);
            }
        }
        if(name==null)name="Selected APK";
        if(!name.toLowerCase(java.util.Locale.US).endsWith(".apk"))throw new IOException("Choose one .apk file. ZIP, APKS, XAPK and AAB bundles are not supported in this beta.");
        if(reported>MAX_BYTES)throw new IOException("Choose an APK smaller than 512 MB.");
        File temporary=new File(context.getFilesDir(),"selected.importing");
        try {
            try(AssetFileDescriptor descriptor=context.getContentResolver().openAssetFileDescriptor(uri,"r",signal)) {
                if(descriptor==null)throw new IOException("The selected file could not be opened");
                try(InputStream in=descriptor.createInputStream();FileOutputStream out=new FileOutputStream(temporary)) {
                importStream=in;progress.check();
                byte[] bytes=new byte[65536];int n;long copied=0;
                while((n=in.read(bytes))!=-1) {
                    progress.check();copied+=n;if(copied>MAX_BYTES)throw new IOException("APK exceeds the 512 MB beta limit");
                    out.write(bytes,0,n);progress.update(copied,reported);
                }
                out.getFD().sync();
                }
            }
            importStream=null;progress.check();
            if(temporary.length()==0)throw new IOException("The selected file is empty");
            int flags=PackageManager.GET_CONFIGURATIONS|PackageManager.GET_PERMISSIONS|
                    (Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
            PackageInfo pkg=context.getPackageManager().getPackageArchiveInfo(temporary.getAbsolutePath(),flags);
            if(pkg==null||pkg.applicationInfo==null)throw new IOException("Android could not read this APK. Check that the download is complete.");
            if(pkg.splitNames!=null&&pkg.splitNames.length>0)throw new IOException("This is a split APK. Choose a complete standalone Wear OS APK.");
            boolean watch=false; if(pkg.reqFeatures!=null)for(FeatureInfo f:pkg.reqFeatures)if("android.hardware.type.watch".equals(f.name))watch=true;
            pkg.applicationInfo.sourceDir=temporary.getAbsolutePath();pkg.applicationInfo.publicSourceDir=temporary.getAbsolutePath();
            String label=pkg.applicationInfo.loadLabel(context.getPackageManager()).toString();
            JSONObject result=new JSONObject();result.put("name",name);result.put("label",label);result.put("package",pkg.packageName);
            result.put("version",pkg.versionName==null?"—":pkg.versionName);result.put("versionCode",Build.VERSION.SDK_INT>=28?pkg.getLongVersionCode():pkg.versionCode);
            result.put("minSdk",pkg.applicationInfo.minSdkVersion);result.put("targetSdk",pkg.applicationInfo.targetSdkVersion);
            result.put("bytes",temporary.length());result.put("sha256",digest(temporary));result.put("watch",watch);
            Signature[] signatures=Build.VERSION.SDK_INT>=28&&pkg.signingInfo!=null?pkg.signingInfo.getApkContentsSigners():pkg.signatures;
            if(signatures!=null&&signatures.length>0)result.put("signer",hex(MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray())));
            JSONArray permissions=new JSONArray();if(pkg.requestedPermissions!=null)for(String p:pkg.requestedPermissions)permissions.put(p);
            result.put("permissions",permissions);
            progress.check();
            if(!temporary.renameTo(file(context)))throw new IOException("Could not save the selected APK");
            context.getSharedPreferences("faceport",0).edit().putString("apk",result.toString()).commit();
            return result;
        } finally { temporary.delete(); }
    }
}
