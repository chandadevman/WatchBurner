package com.tenvyro.faceport;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

/** Per-install ADB identity. Private key at rest is wrapped with Android Keystore AES-GCM. */
final class Identity {
    final PrivateKey key;
    final Certificate certificate;
    private static final String ALIAS = "FacePort.identity.wrap.v1";

    Identity(Context context) throws Exception {
        File base = new File(context.getNoBackupFilesDir(), "identity");
        if (!base.exists() && !base.mkdirs()) throw new IOException("Could not prepare private identity storage");
        File keyFile = new File(base, "private.enc"), certFile = new File(base, "certificate.der");
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        SecretKey wrappingKey = (SecretKey) ks.getKey(ALIAS, null);
        if (keyFile.exists() && certFile.exists()) {
            byte[] stored = read(keyFile);
            if (stored.length < 30 || stored[0] != 12) throw new IOException("Pairing identity is damaged; clear app storage and pair again");
            byte[] iv = java.util.Arrays.copyOfRange(stored, 1, 13);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, wrappingKey, new GCMParameterSpec(128, iv));
            byte[] decoded = cipher.doFinal(stored, 13, stored.length - 13);
            try { key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(decoded)); }
            finally { java.util.Arrays.fill(decoded, (byte)0); }
            try (FileInputStream in = new FileInputStream(certFile)) { certificate = CertificateFactory.getInstance("X.509").generateCertificate(in); }
        } else {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA"); generator.initialize(2048);
            KeyPair pair = generator.generateKeyPair(); key = pair.getPrivate();
            X500Name name = new X500Name("CN=FacePort"); long now = System.currentTimeMillis();
            BouncyCastleProvider bc = new BouncyCastleProvider();
            certificate = new JcaX509CertificateConverter().setProvider(bc).getCertificate(
                    new JcaX509v3CertificateBuilder(name, new BigInteger(128, new SecureRandom()).abs(),
                    new Date(now - 86400000L), new Date(now + 315360000000L), name, pair.getPublic())
                    .build(new JcaContentSignerBuilder("SHA256withRSA").setProvider(bc).build(key)));
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, wrappingKey);
            byte[] clear = key.getEncoded(); byte[] encrypted;
            try { encrypted = cipher.doFinal(clear); } finally { java.util.Arrays.fill(clear, (byte)0); }
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            output.write(cipher.getIV().length); output.write(cipher.getIV()); output.write(encrypted);
            writeAtomic(certFile, certificate.getEncoded()); writeAtomic(keyFile, output.toByteArray());
        }
    }
    static byte[] read(File file) throws IOException {
        if (file.length() > 32768) throw new IOException("Identity exceeds allowed size");
        try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int n; while ((n = in.read(b)) != -1) out.write(b,0,n); return out.toByteArray();
        }
    }
    static void writeAtomic(File file, byte[] bytes) throws IOException {
        File temp = new File(file.getParentFile(), file.getName()+".new");
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(bytes); out.getFD().sync(); }
        if (!temp.renameTo(file)) throw new IOException("Could not save pairing identity");
    }
}
