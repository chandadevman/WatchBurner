package com.tenvyro.faceport;
import java.io.IOException;

/** Parses only the fixed device-probe command; installation requires this gate. */
final class WatchProbe {
    final String model,serial; final int sdk;
    private WatchProbe(String model,int sdk,String serial){this.model=model;this.sdk=sdk;this.serial=serial;}
    static WatchProbe parse(String response)throws IOException{
        String[] rows=response.replace("\r","").trim().split("\n",-1);
        if(rows.length<4||!"FACEPORT_PROBE_DONE".equals(rows[rows.length-1].trim()))throw new IOException("The device did not complete its response");
        String model=rows[0].trim();if(model.isEmpty())throw new IOException("Could not read the watch model");
        int sdk;try{sdk=Integer.parseInt(rows[1].trim());if(sdk<1||sdk>999)throw new NumberFormatException();}catch(Exception e){throw new IOException("Could not read watch Android version");}
        boolean watch=false;for(int i=3;i<rows.length-1;i++)if("feature:android.hardware.type.watch".equals(rows[i].trim()))watch=true;
        if(!watch)throw new IOException("That device does not identify itself as a Wear OS watch. Check the IP address.");
        String serial=rows[2].trim();if(serial.equalsIgnoreCase("unknown")||serial.equalsIgnoreCase("null"))serial="";
        return new WatchProbe(model,sdk,serial);
    }
}
