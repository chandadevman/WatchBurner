# ReapTyc WatchBurner 0.1.2 beta

**Watch Apps & Faces Installer** — Built by Tenvyro.

## Fresh installation

Install **APKs/ReapTyc_WatchBurner_0.1.2_beta.apk on your Android phone**. You do not need FacePort, a previous WatchBurner version, or a WatchBurner app on the watch.

Open WatchBurner and tap **Set up my watch**. Keep both devices on the same trusted Wi-Fi. In the **Connect** tab, follow **A · Pair once** with the current pairing port and six-digit code from the watch's **Pair new device** screen. Then follow **B · Connect each session** using the connection port on the watch's main **Wireless debugging** screen. These ports are usually different.

When the watch is connected, check its model and tap **Choose an APK**. In **Install**, tap **Choose APK**, select the watch app or face, and tap **Install on watch**. Review the confirmation and tap **Send & install**. Wait for **Installed**. If the app says **Check your watch**, the result is unknown: verify on the watch before retrying. Regular apps appear in the watch app list; installed faces still need to be selected in its face picker.

Full setup and troubleshooting are in `START_HERE.md` and the app's **Help** tab.

## What changed

- **Clear first run:** The welcome screen explains that the phone performs the installation and that WatchBurner itself does not go on the watch.
- **ReapTyc styling:** Blue and gold accents, an updated watch-and-transfer icon, clearer cards and a phone-installer label.
- **Guided connection:** Pairing and connection are separated, with distinct port labels and an already-paired shortcut. The address field accepts IPv4 or a complete IP:port; conflicting ports and malformed values receive validation messages.
- **Retained drafts:** IP and port entries survive tab changes, app recreation and reopening. Check the watch for a changed port before reconnecting. Unsubmitted pairing codes clear when leaving the app and are excluded from preferences, saved view state and history.
- **Steadier progress:** Percentage updates modify the status views in place. Rebuilding is reserved for changes that affect controls; drafts and per-tab scroll positions are preserved.
- **Accessible controls:** Flexible heights, two-column tabs on narrow or large-text layouts, associated field labels, selected tab states and polite status announcements.
- **Optional notifications:** **Enable progress notifications** explains its purpose on the welcome screen or in Help. WatchBurner remains usable without that permission.

These are implemented UI changes. The build environment has not rendered this app on Android, so visual polish, keyboard behavior and accessibility interaction still require device review.

## Evidence gates

| Classification | Result and limit |
| --- | --- |
| REAL | Native Android 0.1.2 beta compiled, signed and verified; version code is 3. APK hashes and build verification are recorded in the release evidence. |
| REAL host execution, synthetic inputs | 55 checks passed against the production IPv4/port/pairing-code parser. This does not prove Android field integration or connectivity. |
| SIMULATED | 12 production transport checks passed against a controlled TCP ADB peer, including byte-exact transfer, result interpretation and cancellation. This peer does not exercise real TLS/SPAKE pairing. |
| NOT PROVEN | Actual phone installation/launch, rendered UI, keyboard/scroll/TalkBack behavior, real Galaxy Watch pairing/install, physical update/data retention, and measured battery impact. |
| PLANNED | First acceptance on Galaxy A56 and Galaxy Watch 6; record OS versions and observed results, then patch any defects with a forward-signed update. |
| ESTIMATED | No completion percentage, performance estimate or production-readiness claim. |

## Continuity and recovery

The Android package remains `com.tenvyro.faceport` with the original signer. Existing preference keys, selected-file storage, encrypted identity, Keystore alias, install history and temporary-upload cleanup protocol are preserved. Internal source/build paths remain `apps/faceport` and `build-config/faceport.json`.

If an earlier WatchBurner or FacePort version is installed, install 0.1.2 over it without uninstalling first. Android normally rejects downgrades to lower version codes. Prefer a forward-signed repair to uninstalling and losing local data. Earlier APKs under `rollback/` are recovery references, not instructions to erase settings.

The other companion APKs and the existing IBEV watch face are not modified by this polish pass. No forced orientation or system rotation change is introduced. Physical-device acceptance remains open.
