# Rollback and data protection

## Existing Notices
The existing com.ibev.notices signing identity is preserved. The previous APK is included under rollback/. A normal Android installation will reject a downgrade to a lower version code. Do not uninstall solely to force a downgrade: uninstalling deletes that app's local settings/cache. If a beta regression occurs, first pause notification sharing and report the issue. The safest repair is a forward version with the same key/package. The older source is preserved as a recovery reference, not an instruction to wipe data.

## New products
TwinCharge, BrandCard and DayPilot have their own package IDs. ReapTyc WatchBurner is the same installed app as FacePort: it preserves com.tenvyro.faceport and the original signer. Install version 0.1.1 over FacePort; do not uninstall merely to rename it. Physical in-place upgrade remains untested. BrandCard does not replace the previous IBEV Biz Card. Export DayPilot JSON and BrandCard vCards before uninstalling; uninstalling deletes private local drafts/settings and WatchBurner's pairing identity. Disabling TwinCharge sharing stops its service and periodic job. Revoke notification access for Notices when no longer using it.

## Watch faces
No existing watch-face APK is changed by this bundle. If a newly selected face misbehaves, switch back to the previous face in the normal watch-face picker. WatchBurner only installs the APK explicitly selected and confirmed by the user; package update behavior remains Android's responsibility.

## Signing
The Tenvyro beta signing backup is delivered separately and must stay private. Never publish its password or private key with client source/APKs. Notices uses the previously retained private IBEV Trinity signing identity. Future builds must retain the correct key/package and increment versionCode to update existing installations.

## WatchBurner rename recovery
The previous FacePort 0.1.0 APK is retained in rollback/ as a reference. Android normally rejects a lower versionCode. A forward-signed repair is preferred to uninstalling and losing settings or the encrypted pairing identity. The existing Tenvyro private signing backup also signs ReapTyc WatchBurner.
