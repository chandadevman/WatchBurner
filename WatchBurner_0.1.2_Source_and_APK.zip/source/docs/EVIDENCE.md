# Evidence and release boundaries

## REAL — performed in this build environment

- Recovered the current Notices/watch source and business-card source before changes.
- Built native Java Android APKs using official API 35 tools, compiled DEX, signed and verified APK signatures and archive/native alignment. Exact final files and hashes are in RELEASE_MANIFEST.json and SHA256SUMS.txt.
- Confirmed the Notices beta signing certificate matches the previously delivered Notices APK. Package/provider continuity remains intact; physical in-place update is still untested.
- Ran production business logic and serialization code in host tests. Test logs are included; counts are assertions/contracts, not a completion percentage.
- Static orientation guards passed for each app source tree. No forced orientation was introduced.
- Builder lock and atomic-output tests passed. Failed/overlapping builds cannot overwrite an existing verified APK.
- WatchBurner native library ELF alignment was inspected; physical 16KB page-size runtime is untested.

## SIMULATED — executed tests using controlled inputs

| Product | Executed scope |
| --- | --- |
| TwinCharge | 14 battery-policy assertions; 23 production sync/job contracts with simulated Android/GMS scheduling; resume source contract |
| BrandCard | 63 card/serialization/QR assertions; 22 production-store assertions with preference adapters |
| Notices | 82 logic/input/privacy/dismiss/refresh assertions; 13 source gates |
| DayPilot | 1,019 merge/backup/ordering assertions; 13 production-store regression assertions |
| WatchBurner | 12 production transport, eligibility, transfer, installer-result and cancellation checks against a simulated TCP ADB peer |

BrandCard QR tests encode and decode actual QR data in software. They do not prove a camera can scan a physical round watch at a particular brightness/distance. WatchBurner's simulated ADB peer does not prove real wireless TLS pairing with a Galaxy Watch.

## NOT PROVEN — still needs devices

The available environment could not boot its software Android emulator to an ADB-ready state. API 35 and API 30 attempts produced **no app UI execution and no screenshots**. App launch/rendering, permission dialogs, lifecycle behavior and all hardware flows must be verified on the target phone/watch.

Required acceptance: Galaxy A56 and Galaxy Watch 6 with recorded Android/Wear OS/One UI versions; APK installation and updates; WatchBurner TLS pairing and APK install; real notification relay/dismissal; phone/watch battery sync and overnight drain; BrandCard receipt and wrist QR scan; DayPilot sync/reminders/reboot; screen orientation through tilt/wake/charging/app-return/restart.

## PLANNED — next release gates

Run the device acceptance checklist; patch any observed failures as forward-signed updates; obtain distribution-policy review before a public store launch. No public store release or remote deployment was performed.

## ESTIMATED

No numerical readiness, accuracy, battery-life, completion or performance estimate is claimed. “Beta” means a signed build for controlled acceptance testing, not proof of production readiness.
