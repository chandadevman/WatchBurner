# First device acceptance — TwinCharge first

Record phone model/Android version, watch model/Wear OS/One UI version, date, package version, expected behavior, observed behavior, and screenshot/video where suitable. Protect notification/private contact details in evidence.

| Product | Check | Pass evidence |
| --- | --- | --- |
| WatchBurner | Pair using watch-generated code; connect using its current debug port | Target model and watch feature confirmed |
| WatchBurner | Install one selected watch APK | Real `pm` success; corresponding app opens on watch |
| WatchBurner | Wrong port/expired code/disconnect/cancel | Recoverable explanation; no fabricated success; partial-file cleanup after reconnect |
| TwinCharge | Install same APK on both, enable and refresh | Both remote percentages match actual devices and carry fresh timestamps |
| TwinCharge | Reopen, pause, resume, disconnect, reconnect | Monitoring resumes; pause respected; old data labeled |
| TwinCharge | Alert threshold and charging | Alert below chosen level; no repeated/charging/stale alerts |
| TwinCharge | Phone-battery complication | Provider selectable and tap opens app; stale data shown as unavailable |
| BrandCard | Create/edit/preview three company cards | Correct company details, color and logo survive app restart |
| BrandCard | Save/send/watch receipt | Actual watch matches last acknowledged update |
| BrandCard | Contact and URL QR; .vcf export | Another phone scans/imports intended values |
| Notices | Access denied/granted/revoked | Clear setup state; no crash or fake content |
| Notices | App filter/privacy/pause | Allowed active notices arrive; excluded/redacted data does not |
| Notices | Clear watch cache and explicit dismissal | Local clear leaves phone notices; explicit dismiss affects intended notification only |
| DayPilot | Create/edit/complete/reopen/delete | Correct state persists on phone and syncs on watch |
| DayPilot | Concurrent edit + watch complete | Both intended field changes retained; deleted tasks do not reappear |
| DayPilot | Backup export/import; malformed input | Valid data merges; invalid file rejected without damaging prior tasks |
| DayPilot | Reminder/denial/reboot/timezone | Clear notification permission state and correct approximate reminder behavior |
| All watch apps | Tilt, wake/AOD, charger, app-return and restart | Orientation respects configured wrist/button position |
| All | Overnight battery baseline vs enabled companions | Actual measured drain recorded; no claimed savings without comparison |

If a gate fails, capture app/version, steps and observed result. Keep prior data. Request a forward beta patch; don't factory-reset or uninstall as a speculative repair.
