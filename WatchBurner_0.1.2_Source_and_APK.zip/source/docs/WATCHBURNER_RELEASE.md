# ReapTyc WatchBurner 0.1.1 beta

**Watch Apps & Faces Installer** — Built by Tenvyro.

FacePort is now ReapTyc WatchBurner. The app label, header, notifications, setup/help, new-pairing device label, diagnostic subject and third-party notice heading use the new branding. The installer continues to handle one compatible standalone watch-app or watch-face APK at a time.

## Update

Install APKs/ReapTyc_WatchBurner_0.1.1_beta.apk on the PHONE, over FacePort if it is already installed. Do not uninstall first. There is no WatchBurner watch-side APK.

Package com.tenvyro.faceport, signer, service class, preferences, encrypted ADB identity, Keystore alias and pending-transfer cleanup paths are preserved. Existing paired-device entries may still display FacePort. The established private Tenvyro beta signing backup remains the correct signer.

## Evidence

REAL: native build, APK signature/alignment, increased versionCode 2, same package/certificate, expected app label and preserved source storage contracts verified. The SDK bootstrap now restores executable permissions for the known downloaded build tools.

SIMULATED: all 12 existing production transport checks passed against a controlled TCP ADB peer.

NOT PROVEN: on-device update/data retention, rendered UI, real TLS pairing and installation, battery impact or trademark clearance. The naming search found no same-purpose WatchBurner app; this is a preliminary search, not a legal clearance.

The previous FacePort APK is in rollback/ for reference. Android normally rejects version downgrades; prefer a forward-signed repair rather than uninstalling and losing local data. The other five APK files are byte-identical to the previous bundle.

Internal source/build paths deliberately remain apps/faceport and build-config/faceport.json. Historical FacePort references in unchanged license inventories and old evidence identify the earlier product.
