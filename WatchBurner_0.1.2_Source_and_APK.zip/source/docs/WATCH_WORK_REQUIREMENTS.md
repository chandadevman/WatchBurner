# Standing requirements for Chan's watch projects

Confirmed by Chan on 2026-09-16. Applies to future watch faces, watch apps,
complications, companion apps, updates, and installation instructions.

## Fixed display

- The whole watch face must stay upright relative to the user's configured
  wrist and button position when the watch tilts left, right, forward, or back.
- Do not introduce whole-face gyro effects, sensor-driven rotation, forced
  activity orientation, or changes to system rotation settings unless Chan
  explicitly changes this requirement. Do not force portrait as a workaround;
  respect the watch's configured wrist/button orientation.
- Preserve the approved IBEV → ReapTyc Tech → Tenvyro Tech logo cycle at four
  seconds each. Logo switching and text scrolling do not rotate the display.
- Keep this file and the applicable orientation guard in each future source
  handoff. Review it before changes and before presenting an update as tested.

## Release checks

Run the automated orientation guard on current watch-face XML and native
application sources. For WFF, verify the APK contains exactly that reviewed
XML. The current guard rejects gyro/sensor expressions, group rotation
transforms, and common Android orientation overrides/settings hooks. It is a
conservative regression check, not exhaustive analysis of arbitrary programs
or third-party code. A flagged change requires investigation; do not silently
remove the guard to obtain a passing result.

Before claiming that an update is verified on a watch, record device model,
Wear OS / One UI version, installed package versions, test date, and results:

| Device check | Expected result |
| --- | --- |
| Tilt left/right/forward/back while worn | Whole face remains upright |
| Screen off → wake and active → always-on → active | Orientation stays consistent |
| Put on charger → remove → wear and tilt | Worn face returns to and keeps configured orientation |
| Open Notices/another companion screen → return to face | Orientation stays consistent |
| Install an update over the current version → tilt | Orientation and accepted settings are preserved |
| Restart → wear and tilt | Orientation stays consistent |

Until these are run, mark **device rotation regression NOT PROVEN**. A static
pass, preview, or restart resolving one occurrence is not a physical test pass
for future releases. A beta may be delivered with this limitation stated;
do not describe it as fully device-verified.

## Incident and evidence

- **REAL — user report:** the entire IBEV Command face rotated left/right with
  watch position; restarting stopped the behavior.
- **REAL — inspected artifacts:** v0.1.3 and v0.1.4 face XML is identical outside
  the Notices slot; no added gyro/rotation code was found. Notices v0.1.1 added
  no orientation override in the reviewed source/manifest changes.
- **NOT PROVEN:** the root cause, any causal connection to the app update, and
  permanent prevention of Samsung/Wear OS behavior.
- **PLANNED:** apply these release checks to every future watch update and
  record physical-device results rather than assuming them.
- **SIMULATED:** injected code/XML faults used to test the static guard.
- **ESTIMATED:** no recurrence rate or prevention percentage is claimed.

If it recurs, compare the IBEV face with Settings or a built-in face and record
charging/wake/app-return context before attributing a cause. The confirmed
recovery for this occurrence was a normal restart. Preserve working data and
the prior package; do not use a factory reset or an unrelated APK patch as a
speculative fix. Samsung/Wear OS defects remain outside the guard's control.

## Handoff and rollback

This update adds requirements, static release checks, and incident evidence.
The signed APKs and runtime sources retain their existing bytes and versions.
Prior handoff history preserves the earlier tooling. If the guard has a false
positive, review and narrowly correct the guard while keeping this requirement
and the physical-device checks. Do not mark the incident root cause resolved
without new evidence.
