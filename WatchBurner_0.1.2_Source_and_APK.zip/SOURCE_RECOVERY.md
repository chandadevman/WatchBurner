# WatchBurner source recovery

The current stored companion ZIP is truncated after 46,726,830 bytes and has no ZIP central directory. Its application source, build configuration, dependencies shown here, docs, and APK records occurred before the truncation and were recovered without changes.

Every recovered ZIP record was checked against its original CRC32, and every selected source file was checked against the SHA-256 listed in the bundle's original SHA256SUMS.txt. There were no hash mismatches. The provided standalone APK is byte-identical to the APK in that bundle.

The WatchBurner app-specific source subtree is complete relative to that bundle's file manifest. The common toolchain is missing. MISSING_TOOLCHAIN_FILES.txt lists the missing common scripts, libraries, and resources. No replacement implementation or incompatible toolchain was silently supplied. This package is not claimed to be a complete reproducible build environment. The unrelated incomplete ZXing dependency was not included.

The original malformed ZIP is not included in this delivery. No new app build or physical-device test was performed. Separate private signing archives are intentionally excluded from a GitHub-oriented package.
